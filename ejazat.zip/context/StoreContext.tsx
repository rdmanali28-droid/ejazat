
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Place, Booking, User, BookingStatus, Transaction, UserRole } from '../types';
import { DATABASE } from '../database'; // استيراد قاعدة البيانات الجديدة

interface StoreContextType {
  places: Place[];
  bookings: Booking[];
  users: User[];
  currentUser: User | null;
  transactions: Transaction[];
  addPlace: (place: Place) => void;
  deletePlace: (id: string) => void;
  updatePlace: (place: Place) => void;
  addBooking: (booking: Booking) => { success: boolean; message: string };
  updateBookingStatus: (id: string, status: BookingStatus) => void;
  chargeWallet: (amount: number) => void;
  login: (name: string, role: UserRole) => void;
  logout: () => void;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

export const StoreProvider = ({ children }: { children?: ReactNode }) => {
  // Load data from LocalStorage if available, otherwise use DATABASE initial values
  const [places, setPlaces] = useState<Place[]>(() => {
    const saved = localStorage.getItem('places');
    return saved ? JSON.parse(saved) : DATABASE.places;
  });

  const [bookings, setBookings] = useState<Booking[]>(() => {
    const saved = localStorage.getItem('bookings');
    return saved ? JSON.parse(saved) : DATABASE.bookings;
  });

  const [users, setUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem('users');
    return saved ? JSON.parse(saved) : DATABASE.users;
  });

  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem('transactions');
    return saved ? JSON.parse(saved) : DATABASE.transactions;
  });

  // Current logged in user
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('currentUser');
    return saved ? JSON.parse(saved) : null;
  });

  // Persist to local storage changes
  useEffect(() => { localStorage.setItem('places', JSON.stringify(places)); }, [places]);
  useEffect(() => { localStorage.setItem('bookings', JSON.stringify(bookings)); }, [bookings]);
  useEffect(() => { localStorage.setItem('users', JSON.stringify(users)); }, [users]);
  useEffect(() => { localStorage.setItem('transactions', JSON.stringify(transactions)); }, [transactions]);
  
  // Persist current user session
  useEffect(() => { 
    if (currentUser) {
      localStorage.setItem('currentUser', JSON.stringify(currentUser)); 
    } else {
      localStorage.removeItem('currentUser');
    }
  }, [currentUser]);

  // Sync currentUser with users array when balance changes
  useEffect(() => {
    if (currentUser) {
      const updatedUser = users.find(u => u.id === currentUser.id);
      if (updatedUser) setCurrentUser(updatedUser);
    }
  }, [users]);

  const addPlace = (place: Place) => {
    setPlaces(prev => [place, ...prev]);
  };

  const updatePlace = (updatedPlace: Place) => {
    setPlaces(prev => prev.map(p => p.id === updatedPlace.id ? updatedPlace : p));
  };

  const deletePlace = (id: string) => {
    setPlaces(prev => prev.filter(p => p.id !== id));
  };

  const addBooking = (booking: Booking) => {
    if (!currentUser) return { success: false, message: 'يجب تسجيل الدخول أولاً' };

    // 1. Check Date Conflicts (التحقق من تعارض التواريخ)
    const newStart = new Date(booking.dateFrom).getTime();
    const newEnd = new Date(booking.dateTo).getTime();

    const hasConflict = bookings.some(existingBooking => {
      // Check only for the same place
      if (existingBooking.placeId !== booking.placeId) return false;
      
      // Ignore rejected bookings
      if (existingBooking.status === BookingStatus.REJECTED) return false;

      const existingStart = new Date(existingBooking.dateFrom).getTime();
      const existingEnd = new Date(existingBooking.dateTo).getTime();

      // Check for overlap: (StartA <= EndB) and (EndA >= StartB)
      // Note: Assuming checkout time is roughly checkin time, strict overlap prevents double booking
      return (newStart < existingEnd && newEnd > existingStart);
    });

    if (hasConflict) {
      return { 
        success: false, 
        message: 'عذراً، هذا المكان محجوز بالفعل في التواريخ المختارة. يرجى اختيار تواريخ أخرى.' 
      };
    }

    // 2. Check Balance
    if (currentUser.balance < booking.totalPrice) {
      return { success: false, message: 'رصيد المحفظة غير كافي. يرجى شحن الرصيد.' };
    }

    // 3. Deduct Balance
    const newBalance = currentUser.balance - booking.totalPrice;
    
    // Update User Balance
    setUsers(prev => prev.map(u => u.id === currentUser.id ? { ...u, balance: newBalance } : u));
    
    // Create Transaction Record
    const transaction: Transaction = {
      id: Math.random().toString(36).substr(2, 9),
      userId: currentUser.id,
      amount: booking.totalPrice,
      type: 'payment',
      date: new Date().toISOString(),
      description: `حجز في ${places.find(p => p.id === booking.placeId)?.name || 'عقار'}`
    };
    setTransactions(prev => [transaction, ...prev]);

    // Add Booking
    setBookings(prev => [booking, ...prev]);

    return { success: true, message: 'تم الحجز بنجاح وتم خصم المبلغ من محفظتك' };
  };

  const updateBookingStatus = (id: string, status: BookingStatus) => {
    setBookings(prev => prev.map(b => b.id === id ? { ...b, status } : b));
  };

  const chargeWallet = (amount: number) => {
    if (!currentUser) return;
    
    // Update User Balance
    setUsers(prev => prev.map(u => u.id === currentUser.id ? { ...u, balance: u.balance + amount } : u));

    // Create Transaction Record
    const transaction: Transaction = {
      id: Math.random().toString(36).substr(2, 9),
      userId: currentUser.id,
      amount: amount,
      type: 'charge',
      date: new Date().toISOString(),
      description: 'شحن رصيد المحفظة'
    };
    setTransactions(prev => [transaction, ...prev]);
  };

  // Login Function
  const login = (name: string, role: UserRole) => {
    // Attempt to find user
    let userToLogin = users.find(u => u.role === role);
    
    // Create new user if not found (Simple simulation logic)
    if (!userToLogin) {
      userToLogin = {
        id: Math.random().toString(36).substr(2, 9),
        name: name,
        role: role,
        balance: 0
      };
      setUsers(prev => [...prev, userToLogin!]);
    } else {
        // Update the name if provided
        if (name !== userToLogin.name) {
             userToLogin = { ...userToLogin, name: name };
        }
    }

    setCurrentUser(userToLogin);
  };

  const logout = () => {
    setCurrentUser(null);
  };

  return (
    <StoreContext.Provider value={{
      places,
      bookings,
      users,
      currentUser,
      transactions,
      addPlace,
      deletePlace,
      updatePlace,
      addBooking,
      updateBookingStatus,
      chargeWallet,
      login,
      logout
    }}>
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (!context) throw new Error('useStore must be used within StoreProvider');
  return context;
};
