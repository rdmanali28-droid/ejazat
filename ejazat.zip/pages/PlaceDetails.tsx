
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useStore } from '../context/StoreContext';
import { MapPin, Star, ShieldCheck, CheckCircle, AlertCircle, Wallet, MessageCircle, Map, Clock } from 'lucide-react';
import { BookingStatus } from '../types';

const PlaceDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { places, addBooking, currentUser } = useStore();
  const place = places.find(p => p.id === id);

  const [bookingForm, setBookingForm] = useState({
    name: currentUser?.name || '',
    phone: '',
    dateFrom: '',
    dateTo: '',
    guests: 1
  });
  
  const [totalPrice, setTotalPrice] = useState(0);
  const [errorMsg, setErrorMsg] = useState('');
  const [showSuccess, setShowSuccess] = useState(false);

  // Calculate total price when dates change
  useEffect(() => {
    if (bookingForm.dateFrom && bookingForm.dateTo && place) {
      const start = new Date(bookingForm.dateFrom);
      const end = new Date(bookingForm.dateTo);
      const diffTime = Math.abs(end.getTime() - start.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      
      if (diffDays > 0) {
        setTotalPrice(diffDays * place.price);
      } else {
        setTotalPrice(0);
      }
    }
  }, [bookingForm.dateFrom, bookingForm.dateTo, place]);

  if (!place) {
    return <div className="text-center py-20">المكان غير موجود</div>;
  }

  const handleBook = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!currentUser) {
      setErrorMsg('يجب تسجيل الدخول للحجز');
      return;
    }

    if (totalPrice === 0) {
      setErrorMsg('يرجى اختيار تواريخ صحيحة');
      return;
    }

    const newBooking = {
      id: Math.random().toString(36).substr(2, 9),
      placeId: place.id,
      userId: currentUser.id,
      customerName: bookingForm.name,
      phone: bookingForm.phone,
      dateFrom: bookingForm.dateFrom,
      dateTo: bookingForm.dateTo,
      guests: bookingForm.guests,
      totalPrice: totalPrice,
      status: BookingStatus.PENDING,
      createdAt: new Date().toISOString()
    };

    const result = addBooking(newBooking);

    if (result.success) {
      setShowSuccess(true);
      // Wait a bit longer to let user read the message
      setTimeout(() => {
        setShowSuccess(false);
        navigate('/wallet'); // Or navigate to a "My Bookings" page if it existed
      }, 5000);
    } else {
      setErrorMsg(result.message);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white rounded-2xl overflow-hidden shadow-sm">
            <img src={place.image} alt={place.name} className="w-full h-[400px] object-cover" />
          </div>

          <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
            <div className="flex flex-col md:flex-row justify-between items-start mb-6 gap-4">
              <div>
                <h1 className="text-3xl font-bold text-gray-900 mb-2">{place.name}</h1>
                <div className="flex items-center text-gray-500">
                  <MapPin className="h-5 w-5 ml-1 text-brand-600" />
                  <span className="text-lg">{place.city}</span>
                </div>
              </div>
              <div className="flex flex-col items-end gap-2">
                <div className="flex items-center gap-1 bg-amber-50 px-3 py-1 rounded-lg text-amber-700 font-bold">
                  <Star className="h-5 w-5 fill-amber-500 text-amber-500" />
                  <span>{place.rating}</span>
                </div>
                <div className="text-brand-600 font-bold bg-brand-50 px-3 py-1 rounded-lg">{place.type}</div>
              </div>
            </div>

            {/* Direct Actions */}
            <div className="flex flex-wrap gap-4 mb-8">
               {place.locationUrl && (
                <a 
                  href={place.locationUrl} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex-1 min-w-[150px] flex items-center justify-center gap-2 bg-gray-100 hover:bg-gray-200 text-gray-800 py-3 rounded-xl font-bold transition-colors"
                >
                  <Map className="h-5 w-5" />
                  الموقع الجغرافي
                </a>
              )}
              {place.whatsappNumber && (
                <a 
                  href={`https://wa.me/${place.whatsappNumber}`} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex-1 min-w-[150px] flex items-center justify-center gap-2 bg-green-500 hover:bg-green-600 text-white py-3 rounded-xl font-bold transition-colors shadow-sm hover:shadow-green-500/30"
                >
                  <MessageCircle className="h-5 w-5" />
                  حجز عبر واتساب
                </a>
              )}
            </div>

            <hr className="my-6 border-gray-100" />

            <h3 className="text-xl font-bold mb-4">الوصف</h3>
            <p className="text-gray-600 leading-relaxed text-lg mb-8">
              {place.description}
            </p>

            <h3 className="text-xl font-bold mb-4">المميزات والخدمات</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {place.amenities.map((amenity, idx) => (
                <div key={idx} className="flex items-center gap-2 text-gray-600 bg-gray-50 p-3 rounded-lg">
                  <ShieldCheck className="h-5 w-5 text-brand-500" />
                  <span>{amenity}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Booking Sidebar (System Booking) */}
        <div className="lg:col-span-1">
          <div className="bg-white p-6 rounded-2xl shadow-lg border border-gray-100 sticky top-24">
            <div className="text-center mb-6">
              <span className="text-3xl font-bold text-brand-600">{place.price.toLocaleString()}</span>
              <span className="text-gray-500 mr-1">ريال يمني / ليلة</span>
            </div>
            
            <div className="mb-4 bg-blue-50 text-blue-800 p-3 rounded-lg text-sm mb-4">
                <strong>ملاحظة:</strong> سيتم تعليق المبلغ في محفظتك حتى تتم الموافقة على الحجز من قبل المالك.
            </div>

            {showSuccess ? (
              <div className="text-center py-8 bg-yellow-50 rounded-xl animate-pulse border border-yellow-200">
                <Clock className="h-16 w-16 text-yellow-500 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-yellow-800 mb-2">طلبك قيد الانتظار</h3>
                <p className="text-yellow-700 mb-4 px-4">
                  تم إرسال طلب الحجز بنجاح. سيتم تأكيد الحجز بعد موافقة صاحب العقار.
                </p>
                <div className="text-sm text-gray-500">جاري التحويل للمحفظة...</div>
              </div>
            ) : (
              <form onSubmit={handleBook} className="space-y-4">
                {/* Balance Check */}
                <div className={`p-4 rounded-lg flex justify-between items-center ${currentUser && currentUser.balance >= (totalPrice || place.price) ? 'bg-blue-50 text-blue-700' : 'bg-red-50 text-red-700'}`}>
                  <div className="flex items-center gap-2">
                    <Wallet className="h-5 w-5" />
                    <span className="text-sm font-bold">رصيد محفظتك:</span>
                  </div>
                  <span className="font-bold">{currentUser?.balance.toLocaleString() || 0} ريال</span>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">الاسم الكامل</label>
                  <input 
                    required
                    type="text" 
                    className="w-full rounded-lg border-gray-300 py-2.5 px-3 focus:ring-brand-500 focus:border-brand-500"
                    value={bookingForm.name}
                    onChange={e => setBookingForm({...bookingForm, name: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">رقم الهاتف</label>
                  <input 
                    required
                    type="tel" 
                    className="w-full rounded-lg border-gray-300 py-2.5 px-3 focus:ring-brand-500 focus:border-brand-500"
                    value={bookingForm.phone}
                    onChange={e => setBookingForm({...bookingForm, phone: e.target.value})}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">من تاريخ</label>
                    <input 
                      required
                      type="date" 
                      className="w-full rounded-lg border-gray-300 py-2.5 px-3 focus:ring-brand-500 focus:border-brand-500 text-sm"
                      value={bookingForm.dateFrom}
                      onChange={e => setBookingForm({...bookingForm, dateFrom: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">إلى تاريخ</label>
                    <input 
                      required
                      type="date" 
                      className="w-full rounded-lg border-gray-300 py-2.5 px-3 focus:ring-brand-500 focus:border-brand-500 text-sm"
                      value={bookingForm.dateTo}
                      onChange={e => setBookingForm({...bookingForm, dateTo: e.target.value})}
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">عدد الأشخاص</label>
                  <input 
                    required
                    type="number" 
                    min="1"
                    className="w-full rounded-lg border-gray-300 py-2.5 px-3 focus:ring-brand-500 focus:border-brand-500"
                    value={bookingForm.guests}
                    onChange={e => setBookingForm({...bookingForm, guests: parseInt(e.target.value)})}
                  />
                </div>

                {/* Total Price Display */}
                {totalPrice > 0 && (
                  <div className="border-t border-dashed border-gray-200 pt-4 mt-2">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-gray-600">الإجمالي المتوقع</span>
                      <span className="text-2xl font-bold text-gray-900">{totalPrice.toLocaleString()} <span className="text-sm font-normal text-gray-500">ريال</span></span>
                    </div>
                  </div>
                )}

                {errorMsg && (
                   <div className="bg-red-50 text-red-600 text-sm p-3 rounded-lg flex items-start gap-2">
                     <AlertCircle className="h-5 w-5 flex-shrink-0" />
                     <div className="flex flex-col gap-1">
                       <span>{errorMsg}</span>
                       {errorMsg.includes('رصيد') && (
                         <Link to="/wallet" className="underline font-bold hover:text-red-800">اشحن رصيدك الآن</Link>
                       )}
                     </div>
                   </div>
                )}

                <button 
                  type="submit"
                  className="w-full bg-brand-600 text-white font-bold py-3.5 rounded-xl hover:bg-brand-700 transition shadow-lg hover:shadow-xl transform active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
                  disabled={!currentUser || (totalPrice > 0 && currentUser.balance < totalPrice)}
                >
                  {currentUser && totalPrice > 0 && currentUser.balance < totalPrice ? 'رصيد غير كافي' : 'طلب الحجز (الدفع من المحفظة)'}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PlaceDetails;
