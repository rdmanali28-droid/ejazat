
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../context/StoreContext';
import { MapPin, Lock, User, Building2, UserCircle } from 'lucide-react';
import { UserRole } from '../types';

const Login = () => {
  const navigate = useNavigate();
  const { login } = useStore();
  
  const [formData, setFormData] = useState({
    username: '',
    password: ''
  });
  
  // حالة لاختيار نوع الحساب (مستخدم عادي افتراضياً)
  const [selectedRole, setSelectedRole] = useState<UserRole>('user');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.username) return;

    // تحديد الاسم والصلاحية بناءً على المدخلات
    let role: UserRole = selectedRole;
    let name = formData.username;

    // محاكاة بسيطة: إذا اختار "صاحب عقار"، سيتم تسجيله كـ owner
    // إذا كان الاسم يحتوي على "admin"، نعطيه صلاحية مسؤول (لأغراض التجربة)
    if (formData.username.toLowerCase().includes('admin')) {
      role = 'admin';
      name = 'مدير النظام';
    } else if (selectedRole === 'owner') {
       // إضافة لقب "المالك" للاسم للتوضيح
       if (!name.includes('المالك')) name = name + ' (مالك عقار)';
    }

    login(name, role);
    
    // التوجيه بعد الدخول
    if (role === 'owner' || role === 'admin') {
        navigate('/admin'); // توجيه الملاك للوحة التحكم
    } else {
        navigate('/'); // توجيه المستخدمين للرئيسية
    }
  };

  const handleSocialLogin = (platform: string) => {
    // تسجيل دخول اجتماعي دائماً كمستخدم عادي
    login('مستخدم ' + platform, 'user');
    navigate('/');
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8 bg-white p-8 rounded-2xl shadow-xl border border-gray-100">
        <div className="text-center">
          <div className="mx-auto h-16 w-16 bg-brand-50 rounded-full flex items-center justify-center mb-4">
            <MapPin className="h-8 w-8 text-brand-600" />
          </div>
          <h2 className="text-3xl font-extrabold text-gray-900 mb-2">تسجيل الدخول</h2>
          <p className="text-gray-500 text-sm">مرحباً بك مجدداً في Ejazat</p>
        </div>

        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          
          {/* Role Selector Toggle */}
          <div className="bg-gray-100 p-1 rounded-xl flex">
            <button
              type="button"
              onClick={() => setSelectedRole('user')}
              className={`flex-1 flex items-center justify-center gap-2 py-2.5 text-sm font-bold rounded-lg transition-all ${
                selectedRole === 'user' 
                  ? 'bg-white text-brand-600 shadow-sm' 
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <UserCircle className="h-4 w-4" />
              مستخدم / زائر
            </button>
            <button
              type="button"
              onClick={() => setSelectedRole('owner')}
              className={`flex-1 flex items-center justify-center gap-2 py-2.5 text-sm font-bold rounded-lg transition-all ${
                selectedRole === 'owner' 
                  ? 'bg-white text-brand-600 shadow-sm' 
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <Building2 className="h-4 w-4" />
              صاحب عقار
            </button>
          </div>

          <div className="rounded-md shadow-sm -space-y-px">
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">اسم المستخدم</label>
              <div className="relative">
                <User className="absolute top-3 right-3 h-5 w-5 text-gray-400" />
                <input
                  required
                  type="text"
                  className="appearance-none rounded-xl relative block w-full px-10 py-3 border border-gray-300 placeholder-gray-500 text-gray-900 focus:outline-none focus:ring-brand-500 focus:border-brand-500 focus:z-10 sm:text-sm"
                  placeholder={selectedRole === 'owner' ? "اسم المالك أو الشركة" : "أدخل اسمك أو البريد الإلكتروني"}
                  value={formData.username}
                  onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">كلمة المرور</label>
              <div className="relative">
                <Lock className="absolute top-3 right-3 h-5 w-5 text-gray-400" />
                <input
                  required
                  type="password"
                  className="appearance-none rounded-xl relative block w-full px-10 py-3 border border-gray-300 placeholder-gray-500 text-gray-900 focus:outline-none focus:ring-brand-500 focus:border-brand-500 focus:z-10 sm:text-sm"
                  placeholder="********"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                />
              </div>
            </div>
          </div>

          <div>
            <button
              type="submit"
              className="group relative w-full flex justify-center py-3 px-4 border border-transparent text-sm font-bold rounded-xl text-white bg-brand-600 hover:bg-brand-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-500 transition-colors shadow-lg hover:shadow-xl"
            >
              {selectedRole === 'owner' ? 'دخول كصاحب عقار' : 'تسجيل الدخول'}
            </button>
          </div>
        </form>

        <div className="relative">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-gray-300"></div>
          </div>
          <div className="relative flex justify-center text-sm">
            <span className="px-2 bg-white text-gray-500">أو سجل عبر</span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => handleSocialLogin('Google')}
            className="w-full inline-flex justify-center py-2.5 px-4 border border-gray-300 rounded-xl shadow-sm bg-white text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors"
          >
            <span className="flex items-center gap-2">
               <svg className="h-5 w-5 text-red-500" fill="currentColor" viewBox="0 0 24 24"><path d="M12.545,10.239v3.821h5.445c-0.712,2.315-2.647,3.972-5.445,3.972c-3.332,0-6.033-2.701-6.033-6.032s2.701-6.032,6.033-6.032c1.498,0,2.866,0.549,3.921,1.453l2.814-2.814C17.503,2.988,15.139,2,12.545,2C7.021,2,2.543,6.477,2.543,12s4.478,10,10.002,10c8.396,0,10.249-7.85,9.426-11.748L12.545,10.239z"/></svg>
               Google
            </span>
          </button>
          <button
            onClick={() => handleSocialLogin('Facebook')}
            className="w-full inline-flex justify-center py-2.5 px-4 border border-gray-300 rounded-xl shadow-sm bg-white text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors"
          >
            <span className="flex items-center gap-2">
               <svg className="h-5 w-5 text-blue-600" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.477 2 2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12c0-5.523-4.477-10-10-10z"/></svg>
               Facebook
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default Login;
