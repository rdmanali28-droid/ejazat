
import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { PlaceType, BookingStatus, Place, UserRole, PlaceStatus } from '../types';
import { Plus, Trash2, CheckCircle, XCircle, Clock, Hotel, Users, LayoutDashboard, FileText, Wallet, Building, Filter, Edit, Save, X, AlertTriangle, Eye } from 'lucide-react';
import { Link } from 'react-router-dom';

const AdminDashboard = () => {
  const { places, bookings, users, addPlace, deletePlace, updatePlace, updateBookingStatus, currentUser } = useStore();
  
  // Dashboard Sections
  type Tab = 'overview' | 'bookings' | 'places' | 'users' | 'approvals';
  const [activeTab, setActiveTab] = useState<Tab>('overview');
  
  // Status Filter State
  const [filterStatus, setFilterStatus] = useState<BookingStatus | 'all'>('all');

  // User Role Filter State
  const [filterUserRole, setFilterUserRole] = useState<UserRole | 'all'>('all');

  // Filter Data based on Role
  const isOwner = currentUser?.role === 'owner';
  const isAdmin = currentUser?.role === 'admin';

  const myPlaces = isOwner 
    ? places.filter(p => p.ownerId === currentUser?.id)
    : places;

  const myBookings = isOwner 
    ? bookings.filter(b => myPlaces.find(p => p.id === b.placeId))
    : bookings;

  // Pending Places for Approval (Admin only or Owner viewing their status)
  const pendingPlaces = isAdmin 
    ? places.filter(p => p.status === 'pending')
    : places.filter(p => p.ownerId === currentUser?.id && p.status === 'pending');

  // Apply Status Filter
  const filteredBookings = myBookings.filter(b => {
    if (filterStatus === 'all') return true;
    return b.status === filterStatus;
  });

  // Apply User Role Filter
  const filteredUsers = users.filter(u => {
    if (filterUserRole === 'all') return true;
    return u.role === filterUserRole;
  });

  // Place Form State
  const [formData, setFormData] = useState<Partial<Place>>({
    name: '',
    city: '',
    price: 0,
    type: PlaceType.HOTEL,
    description: '',
    image: 'https://picsum.photos/seed/new/800/600',
    amenities: [],
    rating: 5,
    status: 'pending'
  });

  const [isEditing, setIsEditing] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  if (!currentUser || currentUser.role === 'user') {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center p-8 bg-red-50 rounded-xl text-red-600">
          <h2 className="text-2xl font-bold mb-2">وصول غير مصرح</h2>
          <p>يجب عليك تسجيل الدخول كمسؤول أو مالك للوصول إلى هذه الصفحة.</p>
        </div>
      </div>
    );
  }

  const resetForm = () => {
    setFormData({
      name: '', city: '', price: 0, type: PlaceType.HOTEL,
      description: '', image: 'https://picsum.photos/seed/' + Math.random() + '/800/600',
      amenities: [], rating: 5, status: 'pending'
    });
    setIsEditing(false);
    setEditingId(null);
  };

  const handlePlaceSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.city || !currentUser) return;
    
    if (isEditing && editingId) {
      updatePlace({
        ...formData as Place,
        id: editingId,
        // ownerId and status are preserved usually, but form updates them
      });
      alert('تم تحديث بيانات العقار بنجاح');
    } else {
      addPlace({
        ...formData as Place,
        id: Math.random().toString(36).substr(2, 9),
        ownerId: currentUser.id,
        status: 'pending', // New places via dashboard are pending too
        amenities: ['واي فاي', 'موقف سيارات']
      });
      alert('تم إضافة المكان بنجاح، وهو قيد المراجعة.');
    }
    
    resetForm();
  };

  const handleEditClick = (place: Place) => {
    setFormData(place);
    setIsEditing(true);
    setEditingId(place.id);
  };

  const updatePlaceStatus = (placeId: string, newStatus: PlaceStatus) => {
    const place = places.find(p => p.id === placeId);
    if (place) {
      updatePlace({ ...place, status: newStatus });
      alert(newStatus === 'active' ? 'تم نشر العقار بنجاح' : 'تم رفض العقار');
    }
  };

  const getStatusColor = (status: BookingStatus) => {
    switch (status) {
      case BookingStatus.CONFIRMED: return 'bg-green-100 text-green-700';
      case BookingStatus.REJECTED: return 'bg-red-100 text-red-700';
      default: return 'bg-yellow-100 text-yellow-700';
    }
  };

  // Stats Calculation
  const totalRevenue = myBookings.reduce((sum, b) => b.status === BookingStatus.CONFIRMED ? sum + b.totalPrice : sum, 0);
  const totalBookings = myBookings.length;
  const activeListings = myPlaces.filter(p => p.status === 'active').length;

  return (
    <div className="flex flex-col md:flex-row min-h-screen bg-gray-50">
      {/* Sidebar */}
      <aside className="w-full md:w-64 bg-white border-l border-gray-200 p-6 flex-shrink-0">
        <div className="flex items-center gap-3 mb-8 px-2">
          <div className="w-10 h-10 bg-brand-600 rounded-lg flex items-center justify-center text-white font-bold text-xl">
            {isAdmin ? 'A' : 'O'}
          </div>
          <div>
            <h2 className="font-bold text-gray-900">{currentUser.name}</h2>
            <span className="text-xs text-gray-500 uppercase">{isAdmin ? 'مدير النظام' : 'شريك (مالك)'}</span>
          </div>
        </div>

        <nav className="space-y-1">
          <button onClick={() => setActiveTab('overview')} className={`w-full flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-lg transition ${activeTab === 'overview' ? 'bg-brand-50 text-brand-700' : 'text-gray-600 hover:bg-gray-50'}`}>
            <LayoutDashboard className="h-5 w-5" />
            لوحة القيادة (التقارير)
          </button>
          
          {/* تبويب الطلبات المعلقة */}
          <button onClick={() => setActiveTab('approvals')} className={`w-full flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-lg transition ${activeTab === 'approvals' ? 'bg-brand-50 text-brand-700' : 'text-gray-600 hover:bg-gray-50'}`}>
            <AlertTriangle className="h-5 w-5" />
            <span>طلبات النشر</span>
            {pendingPlaces.length > 0 && <span className="bg-red-500 text-white text-xs px-2 py-0.5 rounded-full">{pendingPlaces.length}</span>}
          </button>

          <button onClick={() => setActiveTab('places')} className={`w-full flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-lg transition ${activeTab === 'places' ? 'bg-brand-50 text-brand-700' : 'text-gray-600 hover:bg-gray-50'}`}>
            <Building className="h-5 w-5" />
            إدارة العقارات
          </button>
          <button onClick={() => setActiveTab('bookings')} className={`w-full flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-lg transition ${activeTab === 'bookings' ? 'bg-brand-50 text-brand-700' : 'text-gray-600 hover:bg-gray-50'}`}>
            <FileText className="h-5 w-5" />
            سجل الحجوزات
          </button>
          {isAdmin && (
            <button onClick={() => setActiveTab('users')} className={`w-full flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-lg transition ${activeTab === 'users' ? 'bg-brand-50 text-brand-700' : 'text-gray-600 hover:bg-gray-50'}`}>
              <Users className="h-5 w-5" />
              إدارة المستخدمين
            </button>
          )}
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-8">
        
        {/* OVERVIEW TAB */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            <h1 className="text-2xl font-bold text-gray-900 mb-6">نظرة عامة والتقارير</h1>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-gray-500 font-medium">إجمالي الإيرادات</h3>
                  <Wallet className="h-8 w-8 text-green-500 bg-green-50 p-1.5 rounded-lg" />
                </div>
                <div className="text-3xl font-bold text-gray-900">{totalRevenue.toLocaleString()} <span className="text-sm font-normal text-gray-400">ريال</span></div>
              </div>
              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-gray-500 font-medium">عدد الحجوزات</h3>
                  <FileText className="h-8 w-8 text-blue-500 bg-blue-50 p-1.5 rounded-lg" />
                </div>
                <div className="text-3xl font-bold text-gray-900">{totalBookings}</div>
              </div>
              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-gray-500 font-medium">العقارات النشطة</h3>
                  <Building className="h-8 w-8 text-purple-500 bg-purple-50 p-1.5 rounded-lg" />
                </div>
                <div className="text-3xl font-bold text-gray-900">{activeListings}</div>
              </div>
            </div>

            {/* Pending Approvals Widget (Only if there are pending items) */}
            {pendingPlaces.length > 0 && (
              <div className="bg-orange-50 border border-orange-100 rounded-xl p-6 mt-6 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="bg-orange-100 p-3 rounded-full">
                    <AlertTriangle className="h-6 w-6 text-orange-600" />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900 text-lg">هناك {pendingPlaces.length} عقار بانتظار المراجعة</h3>
                    <p className="text-gray-600 text-sm">يرجى مراجعة طلبات النشر الجديدة واتخاذ الإجراء اللازم.</p>
                  </div>
                </div>
                <button 
                  onClick={() => setActiveTab('approvals')}
                  className="bg-white text-gray-900 px-4 py-2 rounded-lg font-bold shadow-sm hover:bg-gray-50 border border-gray-200"
                >
                  عرض الطلبات
                </button>
              </div>
            )}
          </div>
        )}

        {/* APPROVALS TAB (New) */}
        {activeTab === 'approvals' && (
          <div className="space-y-6">
            <h1 className="text-2xl font-bold text-gray-900 mb-6">طلبات نشر العقارات</h1>
            
            {pendingPlaces.length === 0 ? (
               <div className="bg-white p-12 text-center rounded-xl border border-gray-200">
                 <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-4" />
                 <h3 className="text-lg font-bold text-gray-900">لا توجد طلبات معلقة</h3>
                 <p className="text-gray-500">جميع العقارات تم مراجعتها.</p>
               </div>
            ) : (
              <div className="grid grid-cols-1 gap-4">
                {pendingPlaces.map(place => (
                  <div key={place.id} className="bg-white p-6 rounded-xl shadow-sm border border-orange-200 flex flex-col md:flex-row gap-6">
                    <img src={place.image} alt={place.name} className="w-full md:w-48 h-32 object-cover rounded-lg" />
                    <div className="flex-grow">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="text-xl font-bold text-gray-900">{place.name}</h3>
                          <p className="text-sm text-gray-500 mb-2">{place.type} في {place.city}</p>
                          <p className="text-gray-600 text-sm line-clamp-2 mb-3">{place.description}</p>
                          <div className="text-brand-600 font-bold">{place.price.toLocaleString()} ريال / ليلة</div>
                        </div>
                        <span className="bg-orange-100 text-orange-800 text-xs font-bold px-2 py-1 rounded">قيد المراجعة</span>
                      </div>
                      
                      {isAdmin ? (
                        <div className="mt-4 pt-4 border-t border-gray-100 flex gap-3 justify-end">
                          <p className="text-sm text-gray-500 flex-grow my-auto">هل تريد نشر هذا العقار على الموقع؟</p>
                          <button 
                            onClick={() => updatePlaceStatus(place.id, 'rejected')}
                            className="px-4 py-2 rounded-lg border border-red-200 text-red-600 hover:bg-red-50 font-bold text-sm"
                          >
                            رفض
                          </button>
                          <button 
                            onClick={() => updatePlaceStatus(place.id, 'active')}
                            className="px-4 py-2 rounded-lg bg-green-600 text-white hover:bg-green-700 font-bold text-sm flex items-center gap-2"
                          >
                            <CheckCircle className="h-4 w-4" />
                            نعم، نشر العقار
                          </button>
                        </div>
                      ) : (
                        <div className="mt-4 pt-4 border-t border-gray-100 text-sm text-gray-500">
                          <Clock className="h-4 w-4 inline ml-1" />
                          طلبك قيد المراجعة من قبل الإدارة. سيتم إشعارك عند النشر.
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* BOOKINGS TAB */}
        {activeTab === 'bookings' && (
          <div>
             <div className="flex flex-col md:flex-row md:items-center justify-between mb-6 gap-4">
               <h1 className="text-2xl font-bold text-gray-900">سجل الحجوزات المستلمة</h1>
               
               {/* Filter Buttons */}
               <div className="flex flex-wrap gap-2">
                 <button 
                   onClick={() => setFilterStatus('all')}
                   className={`px-3 py-1.5 rounded-lg text-sm font-medium transition flex items-center gap-1 ${filterStatus === 'all' ? 'bg-gray-800 text-white' : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'}`}
                 >
                   <Filter className="h-4 w-4" />
                   الكل
                 </button>
                 {Object.values(BookingStatus).map(status => (
                   <button
                     key={status}
                     onClick={() => setFilterStatus(status as BookingStatus)}
                     className={`px-3 py-1.5 rounded-lg text-sm font-medium transition ${filterStatus === status ? 'bg-brand-600 text-white' : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'}`}
                   >
                     {status}
                   </button>
                 ))}
               </div>
             </div>

             <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-right">
                    <thead className="bg-gray-50 text-gray-600 text-sm font-semibold">
                      <tr>
                        <th className="px-6 py-4">الحجز</th>
                        <th className="px-6 py-4">العميل</th>
                        <th className="px-6 py-4">المكان</th>
                        <th className="px-6 py-4">التاريخ</th>
                        <th className="px-6 py-4">الإجمالي</th>
                        <th className="px-6 py-4">الحالة</th>
                        <th className="px-6 py-4 text-center">الإجراء</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {filteredBookings.length === 0 ? (
                        <tr>
                          <td colSpan={7} className="px-6 py-12 text-center text-gray-500">لا توجد حجوزات مطابقة</td>
                        </tr>
                      ) : (
                        filteredBookings.map(booking => (
                        <tr key={booking.id} className="hover:bg-gray-50">
                          <td className="px-6 py-4 text-xs text-gray-500">#{booking.id.substr(0,6)}</td>
                          <td className="px-6 py-4 font-medium">{booking.customerName}</td>
                          <td className="px-6 py-4 text-gray-600">{places.find(p => p.id === booking.placeId)?.name}</td>
                          <td className="px-6 py-4 text-sm text-gray-600">
                            <div className="flex flex-col">
                              <span className="font-medium">{booking.dateFrom}</span>
                              <span className="text-xs text-gray-400">إلى {booking.dateTo}</span>
                            </div>
                          </td>
                          <td className="px-6 py-4 font-bold text-brand-600">{booking.totalPrice.toLocaleString()} ريال</td>
                          <td className="px-6 py-4">
                            <span className={`px-2 py-1 rounded text-xs font-bold ${getStatusColor(booking.status)}`}>{booking.status}</span>
                          </td>
                          <td className="px-6 py-4 flex justify-center gap-2">
                             <button onClick={() => updateBookingStatus(booking.id, BookingStatus.CONFIRMED)} className="text-green-600 hover:bg-green-50 p-1 rounded" title="تأكيد"><CheckCircle className="h-5 w-5"/></button>
                             <button onClick={() => updateBookingStatus(booking.id, BookingStatus.REJECTED)} className="text-red-600 hover:bg-red-50 p-1 rounded" title="رفض"><XCircle className="h-5 w-5"/></button>
                             <button onClick={() => updateBookingStatus(booking.id, BookingStatus.PENDING)} className="text-yellow-600 hover:bg-yellow-50 p-1 rounded" title="تعليق"><Clock className="h-5 w-5"/></button>
                          </td>
                        </tr>
                      )))}
                    </tbody>
                  </table>
                </div>
             </div>
          </div>
        )}

        {/* PLACES TAB */}
        {activeTab === 'places' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-1">
              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 sticky top-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-bold text-lg flex items-center gap-2">
                    {isEditing ? <Edit className="h-5 w-5 text-brand-600" /> : <Plus className="h-5 w-5 text-brand-600" />}
                    {isEditing ? 'تعديل بيانات العقار' : 'إضافة عقار جديد'}
                  </h3>
                  {isEditing && (
                    <button onClick={resetForm} className="text-gray-400 hover:text-red-500">
                      <X className="h-5 w-5" />
                    </button>
                  )}
                </div>
                
                <form onSubmit={handlePlaceSubmit} className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-gray-700">اسم المكان</label>
                    <input required type="text" className="w-full mt-1 border rounded-lg p-2" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-sm font-medium text-gray-700">النوع</label>
                      <select className="w-full mt-1 border rounded-lg p-2" value={formData.type} onChange={e => setFormData({...formData, type: e.target.value as PlaceType})}>
                        {Object.values(PlaceType).map(t => <option key={t} value={t}>{t}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-700">المدينة</label>
                      <input required type="text" className="w-full mt-1 border rounded-lg p-2" value={formData.city} onChange={e => setFormData({...formData, city: e.target.value})} />
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700">السعر (ريال/ليلة)</label>
                    <input required type="number" className="w-full mt-1 border rounded-lg p-2" value={formData.price} onChange={e => setFormData({...formData, price: parseInt(e.target.value)})} />
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700">رابط الصورة</label>
                    <input required type="text" className="w-full mt-1 border rounded-lg p-2 text-xs" value={formData.image} onChange={e => setFormData({...formData, image: e.target.value})} />
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700">الوصف</label>
                    <textarea required className="w-full mt-1 border rounded-lg p-2 h-24" value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} />
                  </div>
                  <div className="flex gap-2">
                    {isEditing && (
                      <button type="button" onClick={resetForm} className="flex-1 bg-gray-100 text-gray-700 py-2 rounded-lg font-bold hover:bg-gray-200">
                        إلغاء
                      </button>
                    )}
                    <button type="submit" className={`flex-1 ${isEditing ? 'bg-blue-600 hover:bg-blue-700' : 'bg-brand-600 hover:bg-brand-700'} text-white py-2 rounded-lg font-bold flex items-center justify-center gap-2`}>
                      {isEditing ? <Save className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
                      {isEditing ? 'حفظ التعديلات' : 'إضافة العقار'}
                    </button>
                  </div>
                </form>
              </div>
            </div>

            <div className="lg:col-span-2 space-y-4">
              <h2 className="font-bold text-xl mb-4">قائمة العقارات المسجلة</h2>
              {myPlaces.map(place => (
                <div key={place.id} className={`bg-white p-4 rounded-xl shadow-sm border transition-all flex items-center justify-between ${editingId === place.id ? 'border-brand-500 ring-2 ring-brand-500 ring-opacity-20' : 'border-gray-200'}`}>
                  <div className="flex items-center gap-4">
                    <img src={place.image} alt="" className="w-20 h-20 rounded-lg object-cover" />
                    <div>
                      <h4 className="font-bold text-gray-900">{place.name}</h4>
                      <div className="flex items-center gap-2 mb-1">
                         <span className="text-sm text-gray-500">{place.type} - {place.city}</span>
                         <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${place.status === 'active' ? 'bg-green-100 text-green-700' : place.status === 'pending' ? 'bg-orange-100 text-orange-700' : 'bg-red-100 text-red-700'}`}>
                           {place.status === 'active' ? 'نشط' : place.status === 'pending' ? 'بانتظار الموافقة' : 'مرفوض'}
                         </span>
                      </div>
                      <div className="text-sm font-medium text-brand-600">{place.price.toLocaleString()} ريال</div>
                      {isAdmin && <div className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded mt-1 inline-block">المالك: {place.ownerId}</div>}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button 
                      onClick={() => handleEditClick(place)}
                      className={`p-2 rounded-full ${editingId === place.id ? 'bg-brand-100 text-brand-700' : 'text-gray-400 hover:bg-gray-100 hover:text-brand-600'}`}
                      title="تعديل"
                    >
                      <Edit className="h-5 w-5" />
                    </button>
                    <button 
                      onClick={() => {
                        if (window.confirm('هل أنت متأكد أنك تريد حذف هذا المكان؟')) {
                          deletePlace(place.id);
                        }
                      }} 
                      className="text-gray-400 hover:bg-red-50 hover:text-red-500 p-2 rounded-full"
                      title="حذف"
                    >
                      <Trash2 className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* USERS TAB (Admin Only) */}
        {activeTab === 'users' && isAdmin && (
          <div>
             <div className="flex flex-col md:flex-row md:items-center justify-between mb-6 gap-4">
               <h1 className="text-2xl font-bold text-gray-900">إدارة المستخدمين</h1>
               
               {/* User Filter Buttons */}
               <div className="flex flex-wrap gap-2">
                 <button 
                   onClick={() => setFilterUserRole('all')}
                   className={`px-3 py-1.5 rounded-lg text-sm font-medium transition flex items-center gap-1 ${filterUserRole === 'all' ? 'bg-gray-800 text-white' : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'}`}
                 >
                   <Filter className="h-4 w-4" />
                   الكل
                 </button>
                 <button 
                   onClick={() => setFilterUserRole('admin')}
                   className={`px-3 py-1.5 rounded-lg text-sm font-medium transition ${filterUserRole === 'admin' ? 'bg-purple-600 text-white' : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'}`}
                 >
                   مسؤولين
                 </button>
                 <button 
                   onClick={() => setFilterUserRole('owner')}
                   className={`px-3 py-1.5 rounded-lg text-sm font-medium transition ${filterUserRole === 'owner' ? 'bg-blue-600 text-white' : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'}`}
                 >
                   ملاك
                 </button>
                 <button 
                   onClick={() => setFilterUserRole('user')}
                   className={`px-3 py-1.5 rounded-lg text-sm font-medium transition ${filterUserRole === 'user' ? 'bg-gray-600 text-white' : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'}`}
                 >
                   مستخدمين
                 </button>
               </div>
             </div>

             <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <table className="w-full text-right">
                  <thead className="bg-gray-50 text-gray-600 text-sm">
                    <tr>
                      <th className="px-6 py-4">الاسم</th>
                      <th className="px-6 py-4">الصلاحية</th>
                      <th className="px-6 py-4">رصيد المحفظة</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {filteredUsers.length === 0 ? (
                      <tr>
                        <td colSpan={3} className="px-6 py-12 text-center text-gray-500">لا يوجد مستخدمين بهذا التصنيف</td>
                      </tr>
                    ) : (
                      filteredUsers.map(u => (
                        <tr key={u.id} className="hover:bg-gray-50">
                          <td className="px-6 py-4 font-bold">{u.name}</td>
                          <td className="px-6 py-4">
                            <span className={`px-2 py-1 rounded text-xs font-bold uppercase ${u.role === 'admin' ? 'bg-purple-100 text-purple-700' : u.role === 'owner' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-700'}`}>
                              {u.role}
                            </span>
                          </td>
                          <td className="px-6 py-4 font-mono">{u.balance.toLocaleString()} ريال</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
             </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default AdminDashboard;
