import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { 
  Wallet as WalletIcon, 
  ArrowUpRight, 
  ArrowDownLeft, 
  History, 
  Smartphone, 
  ArrowRight, 
  CheckCircle, 
  AlertCircle,
  ChevronLeft
} from 'lucide-react';

// تعريف بيانات المحافظ اليمنية
const YEMENI_WALLETS = [
  { 
    id: 'kurimi', 
    name: 'الكريمي (إم فلوس)', 
    color: 'bg-blue-600', 
    textColor: 'text-blue-600',
    icon: 'M',
    description: 'بنك الكريمي الإسلامي'
  },
  { 
    id: 'onecash', 
    name: 'وان كاش (OneCash)', 
    color: 'bg-red-600', 
    textColor: 'text-red-600',
    icon: '1',
    description: 'شركة وان كاش'
  },
  { 
    id: 'floosak', 
    name: 'فلوسك (Floosak)', 
    color: 'bg-indigo-600', 
    textColor: 'text-indigo-600',
    icon: 'F',
    description: 'بنك اليمن والكويت'
  },
  { 
    id: 'jawali', 
    name: 'جوالي (Jawali)', 
    color: 'bg-purple-600', 
    textColor: 'text-purple-600',
    icon: 'J',
    description: 'وايب كاش'
  },
  { 
    id: 'shamil', 
    name: 'شامل موني (Shamil)', 
    color: 'bg-green-600', 
    textColor: 'text-green-600',
    icon: 'S',
    description: 'بنك اليمن والبحرين الشامل'
  },
  { 
    id: 'mobile', 
    name: 'موبايل موني', 
    color: 'bg-orange-600', 
    textColor: 'text-orange-600',
    icon: 'Mb',
    description: 'كاك بنك'
  },
  { 
    id: 'mahfazati', 
    name: 'محفظتي (Mahfazati)', 
    color: 'bg-teal-600', 
    textColor: 'text-teal-600',
    icon: 'Mz',
    description: 'بنك التضامن'
  },
  { 
    id: 'bissat', 
    name: 'بــيس (Peyess)', 
    color: 'bg-yellow-500', 
    textColor: 'text-yellow-600',
    icon: 'P',
    description: 'خدمة الدفع السريع'
  }
];

const Wallet = () => {
  const { currentUser, chargeWallet, transactions } = useStore();
  
  // State variables
  const [selectedWallet, setSelectedWallet] = useState<string | null>(null);
  const [amount, setAmount] = useState<string>('');
  const [phoneNumber, setPhoneNumber] = useState<string>('');
  const [processing, setProcessing] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');

  // Get active wallet object
  const activeWallet = selectedWallet ? YEMENI_WALLETS.find(w => w.id === selectedWallet) : null;

  const handleCharge = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || !phoneNumber) return;

    setProcessing(true);

    // Simulate API delay for payment processing
    setTimeout(() => {
      const val = parseInt(amount);
      if (val > 0) {
        chargeWallet(val);
        setProcessing(false);
        setSuccessMsg(`تم خصم ${val.toLocaleString()} ريال من محفظة ${activeWallet?.name} بنجاح وإضافتها لرصيدك.`);
        
        // Reset form after delay
        setTimeout(() => {
          setSuccessMsg('');
          setAmount('');
          setPhoneNumber('');
          setSelectedWallet(null);
        }, 3000);
      }
    }, 2000);
  };

  // Filter transactions for current user
  const myTransactions = transactions.filter(t => t.userId === currentUser?.id);

  if (!currentUser) return null;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8 text-center md:text-right">
        <h1 className="text-3xl font-bold text-gray-900 flex items-center justify-center md:justify-start gap-3">
          <WalletIcon className="h-8 w-8 text-brand-600" />
          المحفظة الإلكترونية
        </h1>
        <p className="text-gray-500 mt-2">اشحن رصيدك بسهولة باستخدام المحافظ الإلكترونية المحلية.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Right Column: Balance & Charging Section */}
        <div className="lg:col-span-2 space-y-8">
          
          {/* 1. Current Balance Card */}
          <div className="bg-gradient-to-l from-brand-700 to-brand-900 rounded-2xl p-8 text-white shadow-xl relative overflow-hidden">
            <div className="absolute top-0 left-0 w-64 h-64 bg-white/5 rounded-full -ml-20 -mt-20 blur-3xl"></div>
            <div className="absolute bottom-0 right-0 w-40 h-40 bg-black/20 rounded-full -mr-10 -mb-10 blur-xl"></div>
            
            <div className="relative z-10 flex flex-col md:flex-row justify-between items-center gap-6">
              <div>
                <h3 className="text-brand-100 font-medium mb-1 text-lg">الرصيد الحالي المتوفر</h3>
                <div className="text-5xl font-bold flex items-baseline gap-2">
                  {currentUser.balance.toLocaleString()}
                  <span className="text-xl font-normal opacity-80">ريال يمني</span>
                </div>
              </div>
              <div className="bg-white/10 backdrop-blur-md p-4 rounded-xl border border-white/20 text-center min-w-[150px]">
                <span className="block text-xs text-brand-200 mb-1">حالة الحساب</span>
                <span className="block font-bold text-green-400 flex items-center justify-center gap-1">
                  <CheckCircle className="h-4 w-4" />
                  نشط
                </span>
              </div>
            </div>
          </div>

          {/* 2. Wallets Integration Section */}
          <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
            <div className="p-6 border-b border-gray-100">
              <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                <Smartphone className="h-6 w-6 text-brand-600" />
                شحن الرصيد عبر المحافظ
              </h2>
            </div>

            <div className="p-6">
              {!selectedWallet ? (
                /* Wallet Selection Grid */
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {YEMENI_WALLETS.map((wallet) => (
                    <button
                      key={wallet.id}
                      onClick={() => setSelectedWallet(wallet.id)}
                      className="flex flex-col items-center p-4 border border-gray-200 rounded-xl hover:border-brand-500 hover:bg-brand-50 hover:shadow-md transition-all group"
                    >
                      <div className={`w-14 h-14 rounded-full flex items-center justify-center text-white text-xl font-bold mb-3 shadow-sm ${wallet.color} group-hover:scale-110 transition-transform`}>
                        {wallet.icon}
                      </div>
                      <span className="font-bold text-gray-800 text-sm text-center">{wallet.name}</span>
                      <span className="text-[10px] text-gray-400 mt-1">{wallet.description}</span>
                    </button>
                  ))}
                </div>
              ) : (
                /* Payment Form for Selected Wallet */
                <div className="max-w-lg mx-auto animate-fadeIn">
                  <button 
                    onClick={() => { setSelectedWallet(null); setSuccessMsg(''); }}
                    className="flex items-center gap-1 text-gray-500 hover:text-gray-800 mb-6 text-sm font-medium"
                  >
                    <ChevronLeft className="h-4 w-4" />
                    اختيار محفظة أخرى
                  </button>

                  {successMsg ? (
                    <div className="text-center py-10">
                      <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <CheckCircle className="h-10 w-10 text-green-600" />
                      </div>
                      <h3 className="text-xl font-bold text-gray-900 mb-2">تمت العملية بنجاح!</h3>
                      <p className="text-gray-600 mb-6">{successMsg}</p>
                      <button 
                         onClick={() => { setSelectedWallet(null); setSuccessMsg(''); }}
                         className="bg-gray-900 text-white px-6 py-2 rounded-lg font-bold hover:bg-gray-800"
                      >
                        تم
                      </button>
                    </div>
                  ) : (
                    <form onSubmit={handleCharge} className="bg-gray-50 p-6 rounded-2xl border border-gray-200">
                      <div className="flex items-center gap-3 mb-6">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center text-white font-bold shadow-sm ${activeWallet?.color}`}>
                          {activeWallet?.icon}
                        </div>
                        <div>
                          <h3 className="font-bold text-gray-900 text-lg">{activeWallet?.name}</h3>
                          <p className="text-xs text-gray-500">الدفع الآمن المباشر</p>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                             رقم الموبايل (حساب المحفظة)
                          </label>
                          <input 
                            type="tel" 
                            required
                            placeholder="77xxxxxxx"
                            className="w-full p-3 rounded-lg border-gray-300 focus:ring-brand-500 focus:border-brand-500 text-left font-mono"
                            value={phoneNumber}
                            onChange={(e) => setPhoneNumber(e.target.value)}
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                             المبلغ المراد شحنه (ريال)
                          </label>
                          <input 
                            type="number" 
                            required
                            min="1000"
                            step="100"
                            placeholder="مثلاً: 5000"
                            className="w-full p-3 rounded-lg border-gray-300 focus:ring-brand-500 focus:border-brand-500 font-bold text-lg"
                            value={amount}
                            onChange={(e) => setAmount(e.target.value)}
                          />
                          <p className="text-xs text-gray-500 mt-1">الحد الأدنى للشحن 1,000 ريال</p>
                        </div>
                      </div>

                      <button 
                        type="submit" 
                        disabled={processing}
                        className={`w-full mt-6 py-3.5 rounded-xl font-bold text-white shadow-lg transition-all flex items-center justify-center gap-2 ${processing ? 'bg-gray-400 cursor-not-allowed' : `${activeWallet?.color} hover:opacity-90`}`}
                      >
                        {processing ? 'جاري المعالجة...' : `تأكيد الدفع (${amount ? parseInt(amount).toLocaleString() : '0'} ريال)`}
                        {!processing && <ArrowRight className="h-5 w-5" />}
                      </button>
                      
                      <div className="mt-4 flex items-center gap-2 text-xs text-gray-500 justify-center">
                        <AlertCircle className="h-3 w-3" />
                        <span>سيتم إرسال رسالة تأكيد إلى هاتفك لإتمام العملية</span>
                      </div>
                    </form>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Left Column: Transaction History */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 h-full flex flex-col">
            <div className="p-6 border-b border-gray-100 flex items-center justify-between">
              <h3 className="font-bold text-lg text-gray-900 flex items-center gap-2">
                <History className="h-5 w-5 text-gray-500" />
                سجل العمليات
              </h3>
            </div>
            
            <div className="flex-grow overflow-y-auto max-h-[600px] p-2">
              {myTransactions.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-48 text-gray-400">
                  <History className="h-10 w-10 mb-2 opacity-20" />
                  <p>لا توجد عمليات سابقة</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {myTransactions.map((t) => (
                    <div key={t.id} className="bg-gray-50 p-4 rounded-xl border border-gray-100 hover:border-brand-200 transition-colors">
                      <div className="flex justify-between items-start mb-2">
                        <div className={`inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs font-bold ${
                            t.type === 'charge' 
                              ? 'bg-green-100 text-green-700' 
                              : 'bg-red-100 text-red-700'
                          }`}>
                            {t.type === 'charge' ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownLeft className="h-3 w-3" />}
                            {t.type === 'charge' ? 'إيداع' : 'دفع'}
                        </div>
                        <span className="text-xs text-gray-400 font-mono">{new Date(t.date).toLocaleDateString('ar-YE')}</span>
                      </div>
                      <p className="text-gray-800 font-medium text-sm mb-2">{t.description}</p>
                      <div className={`text-right font-bold text-lg ${t.type === 'charge' ? 'text-green-600' : 'text-gray-900'}`}>
                          {t.type === 'charge' ? '+' : '-'}{t.amount.toLocaleString()} <span className="text-xs font-normal text-gray-500">ريال</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};

export default Wallet;