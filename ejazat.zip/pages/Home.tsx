
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../context/StoreContext';
import PlaceCard from '../components/PlaceCard';
import { Search, MapPin, Building, Palmtree, Home as HomeIcon, X, ChevronRight } from 'lucide-react';
import { PlaceType } from '../types';

// بيانات المحافظات مع صور افتراضية
const GOVERNORATES_DATA = [
  { name: 'صنعاء', image: 'https://images.unsplash.com/photo-1560641217-10903328575c?q=80&w=600&auto=format&fit=crop' },
  { name: 'عدن', image: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?q=80&w=600&auto=format&fit=crop' },
  { name: 'إب', image: 'https://images.unsplash.com/photo-1445019980597-93fa8acb246c?q=80&w=600&auto=format&fit=crop' },
  { name: 'الحديدة', image: 'https://images.unsplash.com/photo-1544161515-4ab6ce6db874?q=80&w=600&auto=format&fit=crop' },
  { name: 'المكلا', image: 'https://images.unsplash.com/photo-1571003123894-1f0594d2b5d9?q=80&w=600&auto=format&fit=crop' },
  { name: 'تعز', image: 'https://images.unsplash.com/photo-1564501049412-61c2a3083791?q=80&w=600&auto=format&fit=crop' },
  { name: 'سقطرى', image: 'https://images.unsplash.com/photo-1548233777-628464654b0c?q=80&w=600&auto=format&fit=crop' },
  { name: 'مأرب', image: 'https://images.unsplash.com/photo-1566665797739-1674de7a421a?q=80&w=600&auto=format&fit=crop' },
  { name: 'شبوة', image: 'https://images.unsplash.com/photo-1502085671122-2d218cd434e6?q=80&w=600&auto=format&fit=crop' },
  { name: 'الضالع', image: 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?q=80&w=600&auto=format&fit=crop' }
];

const CATEGORIES = [
  { name: 'فنادق', icon: Building, type: PlaceType.HOTEL, color: 'bg-blue-100 text-blue-600', desc: 'إقامة فاخرة وخدمات متكاملة' },
  { name: 'استراحات', icon: Palmtree, type: PlaceType.RESORT, color: 'bg-green-100 text-green-600', desc: 'للعائلات والمناسبات والراحة' },
  { name: 'شاليهات', icon: HomeIcon, type: PlaceType.CHALET, color: 'bg-orange-100 text-orange-600', desc: 'خصوصية تامة وإطلالات مميزة' },
];

const Home = () => {
  const navigate = useNavigate();
  const { places } = useStore();
  
  const [searchCity, setSearchCity] = useState('');
  const [selectedGovernorate, setSelectedGovernorate] = useState<string | null>(null);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    navigate(`/explore?city=${searchCity}`);
  };

  const handleGovernorateClick = (govName: string) => {
    setSelectedGovernorate(govName);
  };

  const handleCategorySelect = (type: string) => {
    if (selectedGovernorate) {
      navigate(`/explore?city=${selectedGovernorate}&type=${type}`);
      setSelectedGovernorate(null);
    }
  };

  // Filter only active places for display
  const activePlaces = places.filter(p => p.status === 'active');
  const featuredPlaces = activePlaces.slice(0, 3);

  return (
    <div className="space-y-16 pb-16 relative">
      
      {/* Hero Section */}
      <section className="relative h-[600px] flex items-center justify-center overflow-hidden bg-[#0a192f]">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?q=80&w=1920&auto=format&fit=crop"
            alt="Ejazat Yemen Landscape" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0a192f] via-[#0a192f]/50 to-transparent"></div>
        </div>

        <div className="relative z-10 w-full max-w-5xl px-4 text-center mt-10">
          <h1 className="text-4xl md:text-7xl font-extrabold text-white mb-6 drop-shadow-2xl leading-tight">
            مرحباً بك في
            <span className="text-brand-400 block mt-2"> Ejazat Yemen</span>
          </h1>
          <p className="text-gray-100 text-lg md:text-2xl mb-12 max-w-3xl mx-auto font-light leading-relaxed drop-shadow-md">
            اكتشف روعة اليمن السعيد. احجز أرقى الفنادق، الاستراحات، والشاليهات في كافة المحافظات بكل سهولة وأمان.
          </p>

          {/* Search Box */}
          <form onSubmit={handleSearch} className="bg-white/10 backdrop-blur-xl p-2 rounded-2xl border border-white/30 max-w-3xl mx-auto flex shadow-2xl">
            <input 
              type="text" 
              placeholder="ابحث باسم المكان، المدينة، أو نوع العقار..." 
              className="w-full bg-transparent text-white placeholder-gray-200 px-6 py-4 text-lg outline-none"
              value={searchCity}
              onChange={(e) => setSearchCity(e.target.value)}
            />
            <button 
              type="submit"
              className="bg-brand-600 hover:bg-brand-500 text-white px-10 py-4 rounded-xl font-bold transition-all shadow-lg flex items-center gap-2 text-lg hover:scale-105 active:scale-95"
            >
              <Search className="h-6 w-6" />
              بحث
            </button>
          </form>
        </div>
      </section>

      {/* Governorates Section (NEW DESIGN) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-20 relative z-20">
        <div className="bg-white rounded-3xl shadow-xl p-8 border border-gray-100">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-2">وجهات مميزة</h2>
            <p className="text-gray-500">اختر محافظتك المفضلة واستعرض أفضل أماكن الإقامة</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 md:gap-6">
            {GOVERNORATES_DATA.map((gov) => (
              <button
                key={gov.name}
                onClick={() => handleGovernorateClick(gov.name)}
                className="group relative h-40 rounded-2xl overflow-hidden cursor-pointer shadow-md hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1"
              >
                <img 
                  src={gov.image} 
                  alt={gov.name} 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
                <div className="absolute bottom-0 left-0 right-0 p-4 text-center">
                  <div className="flex items-center justify-center gap-1 text-white mb-1">
                    <MapPin className="h-4 w-4 text-brand-400" />
                    <span className="font-bold text-lg">{gov.name}</span>
                  </div>
                  <div className="h-0.5 w-0 bg-brand-400 mx-auto transition-all duration-300 group-hover:w-16"></div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Places */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 bg-gray-50 py-12 rounded-3xl">
        <div className="flex justify-between items-end mb-8">
          <div>
            <h2 className="text-3xl font-bold text-gray-900 mb-2">أحدث الإضافات المميزة</h2>
            <p className="text-gray-500 text-lg">أماكن إقامة مختارة بعناية لتجربة لا تنسى</p>
          </div>
          <button 
            onClick={() => navigate('/explore')}
            className="text-brand-600 font-bold hover:text-brand-700 flex items-center gap-1 group text-lg"
          >
            عرض الكل
            <ChevronRight className="h-6 w-6 transform group-hover:-translate-x-1 transition-transform" />
          </button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {featuredPlaces.map(place => (
            <PlaceCard key={place.id} place={place} />
          ))}
        </div>
      </section>

      {/* Category Selection Modal */}
      {selectedGovernorate && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
          <div 
            className="absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity"
            onClick={() => setSelectedGovernorate(null)}
          ></div>
          
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-3xl relative z-10 overflow-hidden animate-scale-in">
            {/* Modal Header */}
            <div className="bg-brand-600 px-6 py-4 flex justify-between items-center">
              <h3 className="text-xl font-bold text-white flex items-center gap-2">
                <MapPin className="h-5 w-5" />
                تصفح {selectedGovernorate}
              </h3>
              <button 
                onClick={() => setSelectedGovernorate(null)}
                className="p-1 bg-white/20 hover:bg-white/30 rounded-full text-white transition-colors"
              >
                <X className="h-6 w-6" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-8">
              <h4 className="text-center text-gray-800 text-lg font-bold mb-8">
                ما هو نوع العقار الذي تبحث عنه في <span className="text-brand-600">{selectedGovernorate}</span>؟
              </h4>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {CATEGORIES.map((cat) => (
                  <button
                    key={cat.name}
                    onClick={() => handleCategorySelect(cat.type)}
                    className="flex flex-col items-center text-center p-6 rounded-2xl border-2 border-gray-100 hover:border-brand-200 hover:bg-brand-50 transition-all group"
                  >
                    <div className={`w-20 h-20 rounded-full flex items-center justify-center mb-4 ${cat.color} group-hover:scale-110 transition-transform shadow-sm`}>
                      <cat.icon className="h-10 w-10" />
                    </div>
                    <h5 className="font-bold text-gray-900 text-lg mb-2">{cat.name}</h5>
                    <p className="text-xs text-gray-500">{cat.desc}</p>
                    <div className="mt-4 text-brand-600 text-sm font-bold opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1">
                      عرض النتائج <ChevronRight className="h-4 w-4" />
                    </div>
                  </button>
                ))}
              </div>
            </div>
            
            <div className="bg-gray-50 px-6 py-3 text-center border-t border-gray-100">
               <button 
                 onClick={() => {
                   navigate(`/explore?city=${selectedGovernorate}`);
                   setSelectedGovernorate(null);
                 }}
                 className="text-gray-500 hover:text-brand-600 text-sm font-medium underline"
               >
                 عرض كل العقارات في {selectedGovernorate} بدون تحديد النوع
               </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

export default Home;
