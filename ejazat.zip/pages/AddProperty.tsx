
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../context/StoreContext';
import { PlaceType, Place } from '../types';
import { Building, Home, Palmtree, MapPin, CheckCircle, ChevronLeft, ChevronRight, MessageCircle, Map, Image as ImageIcon, LockKeyhole, Clock } from 'lucide-react';

const GOVERNORATES = [
  'صنعاء', 'عدن', 'إب', 'الحديدة', 'المكلا', 
  'تعز', 'سقطرى', 'مأرب', 'شبوة', 'الضالع', 'ذمار', 'عمران', 'حجة', 'المهرة'
];

const AMENITIES_OPTIONS = [
  'واي فاي', 'مسبح', 'موقف سيارات', 'تكييف', 
  'إطلالة بحرية', 'إطلالة جبلية', 'مطعم', 
  'خدمة غرف', 'حديقة', 'سبا', 'مطبخ متكامل', 'مجلس عربي'
];

const AddProperty = () => {
  const navigate = useNavigate();
  const { addPlace, currentUser } = useStore();
  const [step, setStep] = useState(1);
  const [isSubmitted, setIsSubmitted] = useState(false);
  
  // Form State
  const [selectedType, setSelectedType] = useState<PlaceType | null>(null);
  const [selectedCity, setSelectedCity] = useState<string>('');
  const [formData, setFormData] = useState({
    name: '',
    price: '',
    description: '',
    image: '',
    whatsappNumber: '',
    locationUrl: '',
    amenities: [] as string[]
  });

  const handleNext = () => setStep(prev => prev + 1);
  const handleBack = () => setStep(prev => prev - 1);

  const toggleAmenity = (amenity: string) => {
    setFormData(prev => ({
      ...prev,
      amenities: prev.amenities.includes(amenity) 
        ? prev.amenities.filter(a => a !== amenity)
        : [...prev.amenities, amenity]
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedType || !selectedCity || !formData.name || !formData.price) {
      alert('يرجى تعبئة جميع الحقول المطلوبة');
      return;
    }

    const newPlace: Place = {
      id: Math.random().toString(36).substr(2, 9),
      ownerId: currentUser ? currentUser.id : 'guest_user',
      name: formData.name,
      type: selectedType,
      city: selectedCity,
      price: parseInt(formData.price),
      description: formData.description,
      image: formData.image || 'https://images.unsplash.com/photo-1566073771259-6a8506099945?q=80&w=800',
      amenities: formData.amenities,
      rating: 4.5, // Default rating
      status: 'pending', // هام: الحالة الافتراضية هي قيد الانتظار
      whatsappNumber: formData.whatsappNumber,
      locationUrl: formData.locationUrl
    };

    addPlace(newPlace);
    setIsSubmitted(true);
  };

  if (!currentUser) {
     return (
        <div className="min-h-[60vh] flex flex-col items-center justify-center p-4">
           <div className="bg-red-50 text-red-600 p-8 rounded-2xl text-center max-w-md shadow-sm">
              <LockKeyhole className="h-12 w-12 mx-auto mb-4 text-red-400" />
              <h2 className="text-xl font-bold mb-2">تسجيل الدخول مطلوب</h2>
              <p className="mb-6 text-gray-600">يجب عليك تسجيل الدخول بحساب "صاحب عقار" لتتمكن من إضافة عقارك.</p>
              <button 
                onClick={() => navigate('/login')}
                className="bg-red-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-red-700 w-full shadow-lg transition"
              >
                الذهاب لصفحة الدخول
              </button>
           </div>
        </div>
     );
  }

  if (currentUser.role !== 'owner' && currentUser.role !== 'admin') {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center p-4">
         <div className="bg-orange-50 text-orange-800 p-8 rounded-2xl text-center max-w-md shadow-sm border border-orange-100">
            <Building className="h-12 w-12 mx-auto mb-4 text-orange-500" />
            <h2 className="text-xl font-bold mb-2">حساب غير مصرح</h2>
            <p className="mb-6 text-gray-700">
              حسابك الحالي هو "مستخدم عادي". لإضافة عقار، يرجى تسجيل الدخول بحساب "صاحب عقار".
            </p>
            <button 
              onClick={() => navigate('/login')}
              className="bg-orange-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-orange-700 w-full shadow-lg transition"
            >
              تسجيل الدخول كصاحب عقار
            </button>
         </div>
      </div>
   );
  }

  // Success Screen
  if (isSubmitted) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center p-4 animate-fadeIn">
        <div className="bg-white p-10 rounded-3xl shadow-xl text-center max-w-lg border border-gray-100">
          <div className="w-20 h-20 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <Clock className="h-10 w-10 text-yellow-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-3">تم إرسال طلبك بنجاح!</h2>
          <p className="text-gray-600 mb-8 text-lg leading-relaxed">
            شكراً لإضافتك عقار <strong>{formData.name}</strong>. 
            <br/>
            طلبك الآن <span className="font-bold text-yellow-600">قيد المراجعة</span> من قبل إدارة الموقع. سيتم نشره فور الموافقة عليه.
          </p>
          <div className="flex gap-4 justify-center">
            <button 
              onClick={() => navigate('/')}
              className="bg-gray-100 text-gray-700 px-6 py-3 rounded-xl font-bold hover:bg-gray-200"
            >
              العودة للرئيسية
            </button>
            <button 
              onClick={() => navigate('/admin')}
              className="bg-brand-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-brand-700"
            >
              متابعة الطلب
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {/* Progress Bar */}
      <div className="mb-10">
        <div className="flex justify-between items-center relative z-10">
          <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold transition-colors ${step >= 1 ? 'bg-brand-600 text-white' : 'bg-gray-200 text-gray-500'}`}>1</div>
          <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold transition-colors ${step >= 2 ? 'bg-brand-600 text-white' : 'bg-gray-200 text-gray-500'}`}>2</div>
          <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold transition-colors ${step >= 3 ? 'bg-brand-600 text-white' : 'bg-gray-200 text-gray-500'}`}>3</div>
        </div>
        <div className="relative -mt-5 h-1 bg-gray-200 rounded-full mx-2 z-0">
          <div 
            className="absolute top-0 right-0 h-full bg-brand-600 rounded-full transition-all duration-500" 
            style={{ width: step === 1 ? '0%' : step === 2 ? '50%' : '100%' }}
          ></div>
        </div>
        <div className="flex justify-between mt-2 text-xs font-medium text-gray-500">
          <span>نوع العقار</span>
          <span>الموقع</span>
          <span>التفاصيل</span>
        </div>
      </div>

      <div className="bg-white rounded-3xl shadow-lg border border-gray-100 p-6 md:p-10">
        
        {/* STEP 1: SELECT TYPE */}
        {step === 1 && (
          <div className="animate-fadeIn">
            <h2 className="text-2xl font-bold text-center mb-8 text-gray-900">ما هو نوع العقار الذي تريد إضافته؟</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[
                { type: PlaceType.HOTEL, icon: Building, label: 'فندق', color: 'bg-blue-50 text-blue-600 border-blue-200' },
                { type: PlaceType.CHALET, icon: Home, label: 'شاليه', color: 'bg-orange-50 text-orange-600 border-orange-200' },
                { type: PlaceType.RESORT, icon: Palmtree, label: 'استراحة', color: 'bg-green-50 text-green-600 border-green-200' },
              ].map((item) => (
                <button
                  key={item.type}
                  onClick={() => setSelectedType(item.type)}
                  className={`flex flex-col items-center p-8 rounded-2xl border-2 transition-all hover:scale-105 ${selectedType === item.type ? `border-brand-500 ring-2 ring-brand-200 bg-brand-50` : 'border-gray-100 hover:border-brand-200 hover:bg-gray-50'}`}
                >
                  <div className={`w-20 h-20 rounded-full flex items-center justify-center mb-4 ${item.color}`}>
                    <item.icon className="h-10 w-10" />
                  </div>
                  <span className="text-xl font-bold text-gray-800">{item.label}</span>
                  {selectedType === item.type && <CheckCircle className="mt-4 text-brand-600 h-6 w-6" />}
                </button>
              ))}
            </div>
            
            <div className="mt-8 flex justify-end">
              <button 
                onClick={handleNext} 
                disabled={!selectedType}
                className="bg-brand-600 text-white px-8 py-3 rounded-xl font-bold disabled:opacity-50 disabled:cursor-not-allowed hover:bg-brand-700 flex items-center gap-2"
              >
                التالي <ChevronLeft className="h-5 w-5" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 2: SELECT CITY */}
        {step === 2 && (
          <div className="animate-fadeIn">
            <h2 className="text-2xl font-bold text-center mb-8 text-gray-900">أين يقع عقارك؟</h2>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {GOVERNORATES.map((city) => (
                <button
                  key={city}
                  onClick={() => setSelectedCity(city)}
                  className={`p-4 rounded-xl border-2 text-lg font-medium transition-all ${selectedCity === city ? 'border-brand-500 bg-brand-50 text-brand-700' : 'border-gray-100 hover:border-gray-300 text-gray-600'}`}
                >
                  <MapPin className={`h-5 w-5 mx-auto mb-2 ${selectedCity === city ? 'text-brand-600' : 'text-gray-400'}`} />
                  {city}
                </button>
              ))}
            </div>

            <div className="mt-8 flex justify-between">
              <button 
                onClick={handleBack} 
                className="bg-gray-100 text-gray-700 px-8 py-3 rounded-xl font-bold hover:bg-gray-200 flex items-center gap-2"
              >
                <ChevronRight className="h-5 w-5" /> سابق
              </button>
              <button 
                onClick={handleNext} 
                disabled={!selectedCity}
                className="bg-brand-600 text-white px-8 py-3 rounded-xl font-bold disabled:opacity-50 disabled:cursor-not-allowed hover:bg-brand-700 flex items-center gap-2"
              >
                التالي <ChevronLeft className="h-5 w-5" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: DETAILS FORM */}
        {step === 3 && (
          <form onSubmit={handleSubmit} className="animate-fadeIn space-y-6">
            <h2 className="text-2xl font-bold text-center mb-6 text-gray-900">تفاصيل العقار</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">اسم العقار</label>
                <input 
                  type="text" 
                  required
                  placeholder="مثلاً: فندق الراحة السياحي"
                  className="w-full p-3 border border-gray-300 rounded-xl focus:ring-brand-500 focus:border-brand-500"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">السعر لليلة الواحدة (ريال يمني)</label>
                <input 
                  type="number" 
                  required
                  placeholder="مثلاً: 50000"
                  className="w-full p-3 border border-gray-300 rounded-xl focus:ring-brand-500 focus:border-brand-500"
                  value={formData.price}
                  onChange={(e) => setFormData({...formData, price: e.target.value})}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">وصف العقار</label>
              <textarea 
                required
                rows={4}
                placeholder="اكتب وصفاً جذاباً لعقارك يوضح المميزات والموقع..."
                className="w-full p-3 border border-gray-300 rounded-xl focus:ring-brand-500 focus:border-brand-500"
                value={formData.description}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2 flex items-center gap-2">
                  <MessageCircle className="h-4 w-4 text-green-600" />
                  رقم الواتساب للحجز
                </label>
                <input 
                  type="text" 
                  placeholder="9677xxxxxxxx"
                  className="w-full p-3 border border-gray-300 rounded-xl focus:ring-brand-500 focus:border-brand-500"
                  value={formData.whatsappNumber}
                  onChange={(e) => setFormData({...formData, whatsappNumber: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2 flex items-center gap-2">
                  <Map className="h-4 w-4 text-blue-600" />
                  رابط الموقع (Google Maps)
                </label>
                <input 
                  type="text" 
                  placeholder="https://goo.gl/maps/..."
                  className="w-full p-3 border border-gray-300 rounded-xl focus:ring-brand-500 focus:border-brand-500"
                  value={formData.locationUrl}
                  onChange={(e) => setFormData({...formData, locationUrl: e.target.value})}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2 flex items-center gap-2">
                <ImageIcon className="h-4 w-4" />
                رابط صورة العقار
              </label>
              <input 
                type="text" 
                placeholder="https://example.com/image.jpg"
                className="w-full p-3 border border-gray-300 rounded-xl focus:ring-brand-500 focus:border-brand-500"
                value={formData.image}
                onChange={(e) => setFormData({...formData, image: e.target.value})}
              />
              <p className="text-xs text-gray-400 mt-1">يمكنك استخدام رابط صورة من الإنترنت (مؤقتاً)</p>
            </div>

            <div>
              <label className="block text-sm font-bold text-gray-700 mb-3">المميزات المتوفرة</label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {AMENITIES_OPTIONS.map((amenity) => (
                  <label key={amenity} className={`flex items-center gap-2 p-3 rounded-lg border cursor-pointer transition-colors ${formData.amenities.includes(amenity) ? 'bg-brand-50 border-brand-500 text-brand-700' : 'bg-gray-50 border-gray-100 hover:bg-gray-100'}`}>
                    <input 
                      type="checkbox" 
                      className="rounded text-brand-600 focus:ring-brand-500"
                      checked={formData.amenities.includes(amenity)}
                      onChange={() => toggleAmenity(amenity)}
                    />
                    <span className="text-sm">{amenity}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="mt-8 flex justify-between pt-6 border-t border-gray-100">
              <button 
                type="button"
                onClick={handleBack} 
                className="bg-gray-100 text-gray-700 px-8 py-3 rounded-xl font-bold hover:bg-gray-200 flex items-center gap-2"
              >
                <ChevronRight className="h-5 w-5" /> سابق
              </button>
              <button 
                type="submit"
                className="bg-brand-600 text-white px-10 py-3 rounded-xl font-bold hover:bg-brand-700 shadow-lg flex items-center gap-2"
              >
                <CheckCircle className="h-5 w-5" />
                إرسال للمراجعة
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};

export default AddProperty;
