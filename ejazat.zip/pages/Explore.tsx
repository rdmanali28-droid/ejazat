
import React, { useState, useMemo, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useStore } from '../context/StoreContext';
import PlaceCard from '../components/PlaceCard';
import { PlaceType } from '../types';
import { 
  Filter, MapPin, Search, SlidersHorizontal, X, 
  Check, Star, ArrowUpDown, ChevronLeft, ChevronRight, Ban
} from 'lucide-react';

// --- الثوابت والبيانات ---
const GOVERNORATES = [
  'صنعاء', 'عدن', 'إب', 'الحديدة', 'المكلا', 
  'تعز', 'سقطرى', 'مأرب', 'شبوة', 'الضالع'
];

const AMENITIES_LIST = [
  'واي فاي', 'مسبح', 'موقف سيارات', 'تكييف', 
  'إطلالة بحرية', 'إطلالة جبلية', 'مطعم', 
  'خدمة غرف', 'حديقة', 'سبا'
];

const ITEMS_PER_PAGE = 6; // عدد العناصر في الصفحة الواحدة

const Explore = () => {
  const { places } = useStore();
  const [searchParams, setSearchParams] = useSearchParams();
  
  // --- States ---
  const [isMobileFilterOpen, setIsMobileFilterOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);

  // قراءة القيم الأولية من الرابط
  const initialCity = searchParams.get('city') || '';
  const initialType = searchParams.get('type') || '';

  const [filters, setFilters] = useState({
    keyword: '',
    city: initialCity,
    types: initialType ? [initialType] : [] as string[],
    minPrice: '',
    maxPrice: '',
    amenities: [] as string[],
    minRating: 0,
  });

  const [sortBy, setSortBy] = useState<'recommended' | 'priceLow' | 'priceHigh' | 'rating'>('recommended');

  // --- Effects ---
  
  // 1. تحديث الفلاتر عند تغيير الرابط
  useEffect(() => {
    if (initialCity || initialType) {
      setFilters(prev => ({
        ...prev,
        city: initialCity,
        types: initialType ? [initialType] : prev.types
      }));
    }
  }, [initialCity, initialType]);

  // 2. محاكاة تحميل عند تغيير الفلاتر
  useEffect(() => {
    setIsLoading(true);
    setCurrentPage(1); 
    const timer = setTimeout(() => setIsLoading(false), 600);
    return () => clearTimeout(timer);
  }, [filters, sortBy]);

  // 3. الصعود لأعلى الصفحة عند تغيير رقم الصفحة (UX Improvement)
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentPage]);

  // --- Handlers ---
  const handleTypeChange = (type: string) => {
    setFilters(prev => {
      const newTypes = prev.types.includes(type)
        ? prev.types.filter(t => t !== type)
        : [...prev.types, type];
      return { ...prev, types: newTypes };
    });
  };

  const handleAmenityChange = (amenity: string) => {
    setFilters(prev => {
      const newAmenities = prev.amenities.includes(amenity)
        ? prev.amenities.filter(a => a !== amenity)
        : [...prev.amenities, amenity];
      return { ...prev, amenities: newAmenities };
    });
  };

  const clearFilters = () => {
    setFilters({
      keyword: '',
      city: '',
      types: [],
      minPrice: '',
      maxPrice: '',
      amenities: [],
      minRating: 0,
    });
    setSearchParams({});
  };

  const removeFilterTag = (key: keyof typeof filters, value: any) => {
    if (key === 'types') {
      handleTypeChange(value);
    } else if (key === 'amenities') {
      handleAmenityChange(value);
    } else if (key === 'city' || key === 'keyword' || key === 'minPrice' || key === 'maxPrice') {
      setFilters(prev => ({ ...prev, [key]: '' }));
    } else if (key === 'minRating') {
      setFilters(prev => ({ ...prev, minRating: 0 }));
    }
  };

  // --- Filtering Logic (Memoized for Performance) ---
  const allFilteredPlaces = useMemo(() => {
    // 0. Filter by Active Status First
    let result = places.filter(place => place.status === 'active');
    
    result = result.filter(place => {
      // 1. Keyword
      if (filters.keyword) {
        const keyword = filters.keyword.toLowerCase();
        if (!place.name.toLowerCase().includes(keyword) && 
            !place.description.toLowerCase().includes(keyword)) return false;
      }
      // 2. City
      if (filters.city && !place.city.includes(filters.city)) return false;
      // 3. Types
      if (filters.types.length > 0 && !filters.types.includes(place.type)) return false;
      // 4. Price
      if (filters.minPrice && place.price < parseInt(filters.minPrice)) return false;
      if (filters.maxPrice && place.price > parseInt(filters.maxPrice)) return false;
      // 5. Amenities
      if (filters.amenities.length > 0) {
        const hasAll = filters.amenities.every(a => place.amenities.some(pa => pa.includes(a)));
        if (!hasAll) return false;
      }
      // 6. Rating
      if (filters.minRating > 0 && place.rating < filters.minRating) return false;

      return true;
    });

    // --- Sorting ---
    return result.sort((a, b) => {
      switch (sortBy) {
        case 'priceLow': return a.price - b.price;
        case 'priceHigh': return b.price - a.price;
        case 'rating': return b.rating - a.rating;
        default: return 0;
      }
    });
  }, [places, filters, sortBy]);

  // --- Pagination Logic ---
  const totalPages = Math.ceil(allFilteredPlaces.length / ITEMS_PER_PAGE);
  const currentPlaces = allFilteredPlaces.slice(
    (currentPage - 1) * ITEMS_PER_PAGE,
    currentPage * ITEMS_PER_PAGE
  );

  // --- UI Components ---
  const FilterContent = () => (
    <div className="space-y-8">
      {/* Search Input */}
      <div>
        <label className="text-sm font-bold text-gray-900 mb-2 block">بحث بالاسم</label>
        <div className="relative">
          <input
            type="text"
            placeholder="اسم الفندق، الاستراحة..."
            className="w-full pl-4 pr-10 py-2.5 bg-white border border-gray-200 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-brand-500 transition-all"
            value={filters.keyword}
            onChange={(e) => setFilters({ ...filters, keyword: e.target.value })}
          />
          <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
        </div>
      </div>

      {/* City Filter */}
      <div>
        <label className="text-sm font-bold text-gray-900 mb-2 block">المدينة / المحافظة</label>
        <div className="relative">
          <select
            className="w-full pl-4 pr-10 py-2.5 bg-white border border-gray-200 rounded-lg focus:ring-2 focus:ring-brand-500 appearance-none"
            value={filters.city}
            onChange={(e) => setFilters({ ...filters, city: e.target.value })}
          >
            <option value="">كل اليمن</option>
            {GOVERNORATES.map(gov => (
              <option key={gov} value={gov}>{gov}</option>
            ))}
          </select>
          <MapPin className="absolute left-3 top-3 h-4 w-4 text-gray-400 pointer-events-none" />
        </div>
      </div>

      {/* Price Filter */}
      <div>
        <label className="text-sm font-bold text-gray-900 mb-2 block">نطاق السعر (ريال يمني)</label>
        <div className="flex items-center gap-2">
          <input
            type="number"
            placeholder="من"
            className="w-full p-2.5 bg-white border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-brand-500"
            value={filters.minPrice}
            onChange={(e) => setFilters({ ...filters, minPrice: e.target.value })}
          />
          <span className="text-gray-400 font-bold">-</span>
          <input
            type="number"
            placeholder="إلى"
            className="w-full p-2.5 bg-white border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-brand-500"
            value={filters.maxPrice}
            onChange={(e) => setFilters({ ...filters, maxPrice: e.target.value })}
          />
        </div>
      </div>

      {/* Property Type */}
      <div>
        <label className="text-sm font-bold text-gray-900 mb-3 block">نوع العقار</label>
        <div className="space-y-2.5">
          {Object.values(PlaceType).map(type => (
            <label key={type} className="flex items-center gap-3 cursor-pointer group p-2 hover:bg-gray-50 rounded-lg transition-colors -mx-2">
              <div className={`w-5 h-5 rounded border flex items-center justify-center transition-colors ${filters.types.includes(type) ? 'bg-brand-600 border-brand-600' : 'bg-white border-gray-300 group-hover:border-brand-400'}`}>
                {filters.types.includes(type) && <Check className="h-3 w-3 text-white" />}
              </div>
              <input 
                type="checkbox" 
                className="hidden"
                checked={filters.types.includes(type)}
                onChange={() => handleTypeChange(type)}
              />
              <span className={`text-sm ${filters.types.includes(type) ? 'text-gray-900 font-medium' : 'text-gray-600'}`}>{type}</span>
            </label>
          ))}
        </div>
      </div>

      {/* Rating */}
      <div>
        <label className="text-sm font-bold text-gray-900 mb-3 block">تصنيف النجوم</label>
        <div className="flex flex-col gap-2">
          {[5, 4, 3].map(star => (
            <button
              key={star}
              onClick={() => setFilters({ ...filters, minRating: filters.minRating === star ? 0 : star })}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg border w-full transition-all ${filters.minRating === star ? 'border-brand-500 bg-brand-50 text-brand-700' : 'border-gray-200 hover:bg-gray-50'}`}
            >
              <div className="flex">
                {[...Array(5)].map((_, i) => (
                  <Star 
                    key={i} 
                    className={`h-4 w-4 ${i < star ? 'fill-amber-400 text-amber-400' : 'text-gray-300'}`} 
                  />
                ))}
              </div>
              <span className="text-xs text-gray-500 mr-auto">أو أعلى</span>
            </button>
          ))}
        </div>
      </div>

      {/* Amenities */}
      <div>
        <label className="text-sm font-bold text-gray-900 mb-3 block">المرافق والخدمات</label>
        <div className="grid grid-cols-2 gap-2">
          {AMENITIES_LIST.map(amenity => (
            <label key={amenity} className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 p-1 rounded transition-colors">
              <input 
                type="checkbox" 
                className="w-4 h-4 text-brand-600 rounded border-gray-300 focus:ring-brand-500"
                checked={filters.amenities.includes(amenity)}
                onChange={() => handleAmenityChange(amenity)}
              />
              <span className="text-xs text-gray-700">{amenity}</span>
            </label>
          ))}
        </div>
      </div>
    </div>
  );

  const ActiveFilters = () => {
    const hasFilters = filters.keyword || filters.city || filters.types.length > 0 || filters.minPrice || filters.maxPrice || filters.amenities.length > 0 || filters.minRating > 0;
    if (!hasFilters) return null;

    return (
      <div className="flex flex-wrap gap-2 mb-6 animate-fadeIn">
        {filters.keyword && (
          <span className="inline-flex items-center gap-1 bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm">
            "{filters.keyword}"
            <button onClick={() => removeFilterTag('keyword', '')}><X className="h-3 w-3" /></button>
          </span>
        )}
        {filters.city && (
          <span className="inline-flex items-center gap-1 bg-brand-50 text-brand-700 px-3 py-1 rounded-full text-sm">
            <MapPin className="h-3 w-3" /> {filters.city}
            <button onClick={() => removeFilterTag('city', '')}><X className="h-3 w-3" /></button>
          </span>
        )}
        {filters.types.map(type => (
          <span key={type} className="inline-flex items-center gap-1 bg-blue-50 text-blue-700 px-3 py-1 rounded-full text-sm">
            {type}
            <button onClick={() => removeFilterTag('types', type)}><X className="h-3 w-3" /></button>
          </span>
        ))}
        {filters.minPrice && (
          <span className="inline-flex items-center gap-1 bg-green-50 text-green-700 px-3 py-1 rounded-full text-sm">
             أكثر من {filters.minPrice}
            <button onClick={() => removeFilterTag('minPrice', '')}><X className="h-3 w-3" /></button>
          </span>
        )}
        {filters.amenities.map(a => (
          <span key={a} className="inline-flex items-center gap-1 bg-gray-100 text-gray-600 px-3 py-1 rounded-full text-sm">
             {a}
            <button onClick={() => removeFilterTag('amenities', a)}><X className="h-3 w-3" /></button>
          </span>
        ))}
        <button onClick={clearFilters} className="text-xs text-red-600 hover:text-red-800 underline px-2">مسح الكل</button>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Mobile Filter Toggle */}
      <div className="lg:hidden sticky top-20 z-30 bg-white border-b border-gray-200 px-4 py-3 flex justify-between items-center shadow-sm">
        <button 
          onClick={() => setIsMobileFilterOpen(true)}
          className="flex items-center gap-2 text-gray-800 font-bold bg-gray-100 px-4 py-2 rounded-lg hover:bg-gray-200 transition-colors"
        >
          <SlidersHorizontal className="h-5 w-5" />
          <span>تصفية</span>
          <span className="bg-brand-600 text-white text-xs px-2 py-0.5 rounded-full">{allFilteredPlaces.length}</span>
        </button>
        
        <div className="flex items-center gap-2">
           <select 
            value={sortBy} 
            onChange={(e) => setSortBy(e.target.value as any)}
            className="bg-transparent text-sm font-medium text-gray-600 border-none focus:ring-0 cursor-pointer"
          >
            <option value="recommended">المقترح</option>
            <option value="priceLow">الأقل سعراً</option>
            <option value="priceHigh">الأعلى سعراً</option>
            <option value="rating">الأعلى تقييماً</option>
          </select>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          
          {/* Sidebar */}
          <aside className="hidden lg:block w-80 flex-shrink-0">
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-200 sticky top-24 max-h-[calc(100vh-120px)] overflow-y-auto custom-scrollbar">
              <div className="flex items-center justify-between mb-6 pb-4 border-b border-gray-100">
                <h2 className="text-lg font-bold flex items-center gap-2 text-gray-900">
                  <Filter className="h-5 w-5 text-brand-600" />
                  فلترة النتائج
                </h2>
                <button 
                  onClick={clearFilters}
                  className="text-xs text-red-500 hover:text-red-700 font-medium underline transition-colors"
                >
                  إعادة تعيين
                </button>
              </div>
              <FilterContent />
            </div>
          </aside>

          {/* Mobile Drawer */}
          {isMobileFilterOpen && (
            <div className="fixed inset-0 z-50 lg:hidden">
              <div 
                className="absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity" 
                onClick={() => setIsMobileFilterOpen(false)}
              ></div>
              <div className="absolute right-0 top-0 bottom-0 w-full sm:w-96 bg-white shadow-2xl p-6 overflow-y-auto animate-slide-in">
                <div className="flex items-center justify-between mb-8 pb-4 border-b border-gray-100">
                  <h2 className="text-xl font-bold text-gray-900">خيارات البحث المتقدم</h2>
                  <button onClick={() => setIsMobileFilterOpen(false)} className="p-2 bg-gray-100 rounded-full hover:bg-gray-200 transition-colors">
                    <X className="h-6 w-6 text-gray-600" />
                  </button>
                </div>
                <FilterContent />
                <div className="mt-8 pt-4 border-t border-gray-100 sticky bottom-0 bg-white pb-4">
                  <div className="flex gap-3">
                    <button 
                      onClick={clearFilters}
                      className="flex-1 bg-gray-100 text-gray-700 font-bold py-3 rounded-xl hover:bg-gray-200 transition-colors"
                    >
                      مسح الكل
                    </button>
                    <button 
                      onClick={() => setIsMobileFilterOpen(false)}
                      className="flex-[2] bg-brand-600 text-white font-bold py-3 rounded-xl hover:bg-brand-700 transition-colors shadow-lg shadow-brand-500/30"
                    >
                      عرض {allFilteredPlaces.length} نتيجة
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Main Results */}
          <main className="flex-1">
            {/* Header */}
            <div className="hidden lg:flex items-center justify-between mb-6 bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
              <h1 className="text-xl font-bold text-gray-900 flex items-center gap-3">
                {filters.city ? `نتائج البحث في ${filters.city}` : 'استكشف جميع أماكن الإقامة'}
                <span className="text-sm font-medium text-brand-700 bg-brand-50 px-3 py-1 rounded-full border border-brand-100">
                  {allFilteredPlaces.length} خيار متاح
                </span>
              </h1>
              
              <div className="flex items-center gap-3">
                <span className="text-gray-500 text-sm font-medium">ترتيب حسب:</span>
                <div className="relative group">
                  <select 
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value as any)}
                    className="appearance-none bg-gray-50 border border-gray-200 text-gray-700 py-2 pl-4 pr-10 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-500 font-medium cursor-pointer min-w-[180px] transition-all group-hover:border-brand-300"
                  >
                    <option value="recommended">الموصى به</option>
                    <option value="priceLow">السعر: من الأقل للأعلى</option>
                    <option value="priceHigh">السعر: من الأعلى للأقل</option>
                    <option value="rating">تقييم النزلاء (الأعلى)</option>
                  </select>
                  <ArrowUpDown className="absolute left-3 top-2.5 h-4 w-4 text-gray-400 pointer-events-none" />
                </div>
              </div>
            </div>

            <ActiveFilters />

            {/* Content State Handling */}
            {isLoading ? (
               // Skeleton Loading State
               <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                 {[1, 2, 3, 4, 5, 6].map(i => (
                   <div key={i} className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 h-96 animate-pulse">
                     <div className="bg-gray-200 h-48 rounded-xl mb-4"></div>
                     <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                     <div className="h-4 bg-gray-200 rounded w-1/2 mb-4"></div>
                     <div className="h-10 bg-gray-200 rounded mt-auto"></div>
                   </div>
                 ))}
               </div>
            ) : currentPlaces.length > 0 ? (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 mb-8">
                  {currentPlaces.map(place => (
                    <PlaceCard key={place.id} place={place} />
                  ))}
                </div>

                {/* Pagination */}
                {totalPages > 1 && (
                  <div className="flex items-center justify-center gap-2 mt-8 py-4 border-t border-gray-200">
                    <button 
                      onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                      disabled={currentPage === 1}
                      className="flex items-center justify-center px-4 py-2 rounded-lg border border-gray-300 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed text-gray-700 bg-white shadow-sm transition-all"
                    >
                      <ChevronRight className="h-5 w-5 ml-1" />
                      السابق
                    </button>
                    
                    <div className="flex gap-1">
                      {[...Array(totalPages)].map((_, idx) => (
                        <button
                          key={idx}
                          onClick={() => setCurrentPage(idx + 1)}
                          className={`w-10 h-10 rounded-lg font-bold transition-all shadow-sm ${
                            currentPage === idx + 1 
                            ? 'bg-brand-600 text-white scale-110 ring-2 ring-brand-200' 
                            : 'bg-white border border-gray-300 text-gray-700 hover:bg-gray-50'
                          }`}
                        >
                          {idx + 1}
                        </button>
                      ))}
                    </div>

                    <button 
                      onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                      disabled={currentPage === totalPages}
                      className="flex items-center justify-center px-4 py-2 rounded-lg border border-gray-300 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed text-gray-700 bg-white shadow-sm transition-all"
                    >
                      التالي
                      <ChevronLeft className="h-5 w-5 mr-1" />
                    </button>
                  </div>
                )}
              </>
            ) : (
              <div className="bg-white rounded-3xl p-16 text-center border border-dashed border-gray-300 flex flex-col items-center justify-center min-h-[400px]">
                <div className="w-24 h-24 bg-gray-50 rounded-full flex items-center justify-center mb-6 animate-bounce-slow">
                  <Ban className="h-10 w-10 text-gray-400" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-2">لم يتم العثور على نتائج</h3>
                <p className="text-gray-500 max-w-md mx-auto mb-8">
                  للأسف، لا توجد أماكن تطابق معايير البحث الحالية أو أن العقارات المطلوبة بانتظار الموافقة. جرب تغيير المدينة أو إزالة بعض الفلاتر.
                </p>
                <button 
                  onClick={clearFilters}
                  className="bg-brand-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-brand-700 transition-all shadow-lg hover:shadow-brand-500/20"
                >
                  إزالة جميع الفلاتر
                </button>
              </div>
            )}
          </main>
        </div>
      </div>
    </div>
  );
};

export default Explore;
