
import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useStore } from '../context/StoreContext';
import { MapPin, UserCircle, LogOut, Menu, X, Wallet, ArrowRight, LogIn, PlusCircle } from 'lucide-react';

const Layout = ({ children }: { children?: React.ReactNode }) => {
  const { currentUser, logout } = useStore();
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  const isActive = (path: string) => location.pathname === path ? 'text-brand-600 bg-brand-50' : 'text-gray-600 hover:text-brand-600 hover:bg-gray-50';

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  // التحقق مما إذا كان المستخدم يملك صلاحية إضافة عقار (مالك أو مسؤول)
  const canAddProperty = currentUser && (currentUser.role === 'owner' || currentUser.role === 'admin');

  // Hide Navbar elements on login page if desired
  const isLoginPage = location.pathname === '/login';

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      {/* Navbar */}
      <nav className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-20">
            <div className="flex items-center gap-4">
              {/* Back Button (Only if not on Home) */}
              {location.pathname !== '/' && (
                <button 
                  onClick={() => navigate(-1)}
                  className="flex items-center gap-1 text-gray-500 hover:text-brand-600 hover:bg-gray-50 px-3 py-2 rounded-lg transition-colors"
                  title="عودة للصفحة السابقة"
                >
                  <ArrowRight className="h-5 w-5" />
                  <span className="hidden sm:inline font-medium text-sm">عودة</span>
                </button>
              )}

              <Link to="/" className="flex-shrink-0 flex items-center gap-2">
                <MapPin className="h-8 w-8 text-brand-600" />
                <span className="text-2xl font-bold text-gray-900 tracking-tight">Ejazat</span>
              </Link>
            </div>

            {/* Desktop Menu */}
            <div className="hidden md:flex md:items-center md:gap-4">
              <Link to="/" className={`px-4 py-2 rounded-lg font-medium transition-colors ${isActive('/')}`}>
                الرئيسية
              </Link>
              <Link to="/explore" className={`px-4 py-2 rounded-lg font-medium transition-colors ${isActive('/explore')}`}>
                تصفح الأماكن
              </Link>
              
              {/* Dashboard Link based on Role */}
              {canAddProperty && (
                <Link to="/admin" className={`px-4 py-2 rounded-lg font-medium transition-colors ${isActive('/admin')}`}>
                  {currentUser?.role === 'admin' ? 'الإدارة العامة' : 'إدارة عقاراتي'}
                </Link>
              )}

              {/* Wallet Link */}
              {currentUser && (
                <Link to="/wallet" className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${isActive('/wallet')}`}>
                  <Wallet className="h-4 w-4" />
                  <span>المحفظة: {currentUser.balance.toLocaleString()} ريال</span>
                </Link>
              )}
              
              <div className="h-6 w-px bg-gray-300 mx-2"></div>

              {/* Add Property Button (Visible ONLY to Owners/Admins) */}
              {canAddProperty && (
                <Link 
                  to="/add-property" 
                  className="flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-white bg-brand-500 hover:bg-brand-600 transition shadow-md hover:shadow-lg transform hover:-translate-y-0.5"
                >
                  <PlusCircle className="h-5 w-5" />
                  <span>إضافة عقار</span>
                </Link>
              )}

              {/* User Account / Login Button */}
              {currentUser ? (
                <div className="relative group">
                  <button className="flex items-center gap-2 px-4 py-2 rounded-full border border-gray-200 hover:bg-gray-50 transition text-sm font-medium bg-white">
                    <UserCircle className="h-5 w-5 text-brand-600" />
                    <div className="text-right">
                      <span className="block text-xs text-gray-500">مرحباً</span>
                      <span className="block font-bold leading-none text-brand-700">{currentUser.name}</span>
                    </div>
                  </button>
                  
                  {/* Dropdown User Menu */}
                  <div className="absolute left-0 mt-2 w-48 bg-white rounded-lg shadow-xl border border-gray-100 hidden group-hover:block p-1">
                    <div className="px-3 py-2 text-xs font-bold text-gray-400 border-b border-gray-100 mb-1">حسابي ({currentUser.role === 'user' ? 'مستخدم' : 'مالك'})</div>
                    <Link to="/wallet" className="block text-right px-3 py-2 text-sm hover:bg-gray-50 rounded">المحفظة</Link>
                    <button onClick={handleLogout} className="w-full text-right px-3 py-2 text-sm hover:bg-red-50 text-red-600 rounded flex items-center gap-2">
                       <LogOut className="h-4 w-4" />
                       تسجيل خروج
                    </button>
                  </div>
                </div>
              ) : (
                !isLoginPage && (
                  <Link 
                    to="/login" 
                    className="flex items-center gap-2 text-brand-600 font-bold hover:bg-brand-50 px-4 py-2.5 rounded-xl transition"
                  >
                    <LogIn className="h-5 w-5" />
                    تسجيل دخول
                  </Link>
                )
              )}
            </div>

            {/* Mobile menu button */}
            <div className="flex items-center md:hidden">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="p-2 rounded-md text-gray-600 hover:text-gray-900 hover:bg-gray-100"
              >
                {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden bg-white border-t border-gray-100">
            <div className="px-2 pt-2 pb-3 space-y-1">
              <Link to="/" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-gray-900 hover:bg-gray-50">الرئيسية</Link>
              <Link to="/explore" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-gray-900 hover:bg-gray-50">تصفح الأماكن</Link>
              
              {canAddProperty && (
                <Link to="/add-property" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 rounded-md text-base font-bold text-brand-600 bg-brand-50">إضافة عقار</Link>
              )}
              
              {currentUser ? (
                <>
                  <Link to="/wallet" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-gray-900 hover:bg-gray-50">المحفظة ({currentUser.balance})</Link>
                  {canAddProperty && (
                    <Link to="/admin" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium text-brand-600 hover:bg-gray-50">لوحة التحكم</Link>
                  )}
                  <button onClick={handleLogout} className="w-full text-right block px-3 py-2 rounded-md text-base font-medium text-red-600 hover:bg-red-50">تسجيل خروج</button>
                </>
              ) : (
                <Link to="/login" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 rounded-md text-base font-bold text-brand-600 hover:bg-brand-50">تسجيل دخول</Link>
              )}
            </div>
          </div>
        )}
      </nav>

      {/* Main Content */}
      <main className="flex-grow">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <MapPin className="h-6 w-6 text-brand-400" />
                <span className="text-xl font-bold">Ejazat</span>
              </div>
              <p className="text-gray-400 text-sm leading-relaxed">
                منصتك الأولى لحجز أفضل الفنادق، الاستراحات، الشاليهات، والفلل في جميع أنحاء اليمن. تجربة حجز سهلة وآمنة.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-bold mb-4 text-brand-400">روابط سريعة</h3>
              <ul className="space-y-2 text-gray-300">
                <li><Link to="/" className="hover:text-white transition">الرئيسية</Link></li>
                <li><Link to="/explore" className="hover:text-white transition">بحث عن أماكن</Link></li>
                <li><Link to="/add-property" className="hover:text-white transition">أضف عقارك</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-bold mb-4 text-brand-400">تواصل معنا</h3>
              <p className="text-gray-300 text-sm mb-2">صنعاء، اليمن</p>
              <p className="text-gray-300 text-sm">support@ejazat.com</p>
              <p className="text-gray-300 text-sm">+967 770 000 000</p>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-500 text-sm">
            © {new Date().getFullYear()} Ejazat. جميع الحقوق محفوظة.
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
