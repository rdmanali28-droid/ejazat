import React from 'react';
import { Place } from '../types';
import { MapPin, Star, Building2, MessageCircle, Map } from 'lucide-react';
import { Link } from 'react-router-dom';

interface PlaceCardProps {
  place: Place;
}

const PlaceCard: React.FC<PlaceCardProps> = ({ place }) => {
  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition-shadow duration-300 flex flex-col h-full group">
      <div className="relative h-56 overflow-hidden">
        <img 
          src={place.image} 
          alt={place.name} 
          className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-bold text-gray-800 shadow-sm">
          {place.type}
        </div>
      </div>
      
      <div className="p-5 flex flex-col flex-grow">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-lg font-bold text-gray-900 line-clamp-1">{place.name}</h3>
          <div className="flex items-center gap-1 bg-amber-50 px-2 py-0.5 rounded text-amber-700 text-sm font-medium">
            <Star className="h-3 w-3 fill-amber-500 text-amber-500" />
            <span>{place.rating}</span>
          </div>
        </div>
        
        <div className="flex items-center text-gray-500 text-sm mb-4">
          <MapPin className="h-4 w-4 ml-1" />
          <span>{place.city}</span>
        </div>

        <p className="text-gray-600 text-sm line-clamp-2 mb-4 flex-grow">
          {place.description}
        </p>

        {/* Action Buttons: Location and WhatsApp */}
        <div className="grid grid-cols-2 gap-3 mb-4">
          {place.locationUrl && (
            <a 
              href={place.locationUrl} 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 bg-gray-100 hover:bg-gray-200 text-gray-700 py-2 rounded-lg text-sm font-bold transition-colors"
            >
              <Map className="h-4 w-4" />
              الموقع
            </a>
          )}
          {place.whatsappNumber && (
            <a 
              href={`https://wa.me/${place.whatsappNumber}`} 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 bg-green-50 hover:bg-green-100 text-green-700 py-2 rounded-lg text-sm font-bold transition-colors"
            >
              <MessageCircle className="h-4 w-4" />
              حجز
            </a>
          )}
        </div>

        <div className="mt-auto pt-4 border-t border-gray-50 flex items-center justify-between">
          <div>
            <span className="text-xl font-bold text-brand-600">{place.price.toLocaleString()}</span>
            <span className="text-xs text-gray-400 mr-1">ريال / ليلة</span>
          </div>
          <Link 
            to={`/place/${place.id}`}
            className="bg-brand-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-brand-700 transition-colors"
          >
            عرض التفاصيل
          </Link>
        </div>
      </div>
    </div>
  );
};

export default PlaceCard;