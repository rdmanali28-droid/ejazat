
export enum PlaceType {
  HOTEL = 'فندق',
  RESORT = 'استراحة',
  VILLA = 'فيلا',
  CHALET = 'شاليه'
}

export enum BookingStatus {
  PENDING = 'قيد المراجعة',
  CONFIRMED = 'مؤكد',
  REJECTED = 'مرفوض'
}

export type UserRole = 'admin' | 'owner' | 'user';
export type PlaceStatus = 'active' | 'pending' | 'rejected';

export interface User {
  id: string;
  name: string;
  role: UserRole;
  balance: number;
}

export interface Place {
  id: string;
  ownerId: string;
  name: string;
  type: PlaceType;
  city: string;
  price: number;
  description: string;
  image: string;
  amenities: string[];
  rating: number;
  status: PlaceStatus; // الحقل الجديد لحالة العقار
  locationUrl?: string;
  whatsappNumber?: string;
}

export interface Booking {
  id: string;
  placeId: string;
  userId: string;
  customerName: string;
  phone: string;
  dateFrom: string;
  dateTo: string;
  guests: number;
  totalPrice: number;
  status: BookingStatus;
  createdAt: string;
}

export interface Transaction {
  id: string;
  userId: string;
  amount: number;
  type: 'charge' | 'payment' | 'refund';
  date: string;
  description: string;
}
